import React, { Fragment } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Landing from "./components/layout/Landing";
import Register from "./components/auth/Register";
import Ranking from "./components/ranking/Ranking";
import RequestList from "./components/request/RequestList";
import Request from "./components/request/Request";
import NewRequest from "./components/request-form/NewRequest"
import MainNavigation from "./components/shared/Navigation/MainNavigation";
import Users from "./components/profile/Users";
import CreateFavor from "./components/favor-form/CreateFavor";
import Login from "./components/auth/Login";
import Logout from "./components/auth/Logout";
import Notification from "react-notifications-component";
import PeopleFavorDetails from "./components/favor/PeopleFavorDetails";
import UserFavorDetails from "./components/favor/UserFavorDetails";

import PrivateRoute from "./components/shared/Utility/PrivateRoute";

const App = () => (
  <Router>
    <Fragment>
      <MainNavigation />
      <Route exact path="/" component={Landing} />
      <Notification />
      <Switch>
        <PrivateRoute exact path="/profile" component={Users} />
        <Route exact path="/register" component={Register} />
        <Route exact path="/ranking" component={Ranking} />
        <Route exact path="/requests" component={RequestList} />
        <Route exact path="/request/:id" component={Request} />
        <Route exact path="/login" component={Login} />
        <PrivateRoute exact path="/favor/people/:id" component={PeopleFavorDetails} />
        <PrivateRoute exact path="/favor/user/:id" component={UserFavorDetails} />
        <PrivateRoute exact path="/logout" component={Logout} />
        <PrivateRoute exact path="/create-favor" component={CreateFavor} />
        <PrivateRoute exact path="/create-request" component={NewRequest} />
      </Switch>
    </Fragment>
  </Router>
);

export default App;
