import axios from 'axios';
import { addNotification } from '../components/shared/Utility/Alert';

// Create a new request
export const createRequest = async (newRequest, setIsLoading, history) => {
    try {
        // Set header and body
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const body = JSON.stringify(newRequest);
        const newPost = await axios.post(`/api/requests`, body, config)
        const newPostId = newPost.data.data.user.requestid
        // Redirect to the Request detail page
        history.push(`/request/${newPostId}`);
    } catch (err) {
        console.error(err.message);
        setIsLoading(false);
        addNotification('Submission failed', 'Task should be less than 250 characters in English', 'danger');
    }
}

// Get all current requests
export const getAllRequests = async () => {
    try {
        const res = await axios.get('/api/requests');
        return res.data
    } catch (err) {
        console.error(err);
    }
}

// Get request by request id
export const getRequest = async (id) => {
    try {
        // Get the request data by request id
        const res = await axios.get(`/api/requests/${id}`);
        return res.data
    } catch (err) {
        console.error(err);
    }
}

// Delete the request
export const deleteRequest = async (id, history) => {
    try {
        const confirm = window.confirm(
            "Are you sure you want to delete the request?"
        );
        if (confirm === true) {
            await axios.delete(`/api/requests/${id}`);
            addNotification(
                "Request deleted",
                "The request has been deleted!",
                "success"
            );
            // Redirect to the Requests list page
            history.push(`/requests`);
        }
    } catch (err) {
        console.error(err.message);
        addNotification(
            "Failed to delete the reqeust",
            "The request cannot be deleted if there is any reward",
            "danger"
        );
    }
}

// Update the Request with the completed date
export const completeRequest = async (id, setIsLoading, history) => {
    try {
        await axios.post(`/api/requests/${id}`)
            .then(async () => {
                // Fetch the data of the completed request
                const results = await axios.get(`/api/requests/${id}/completed`);
                const favors = results.data;
                // Set header and body
                const config = {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
                // Store the reward as the favor item
                favors.map(async (favor) => {
                    await axios.post(`/api/favors/lender`, favor, config);
                })
            })
        addNotification('Submission complete', 'The task has been completed! We have added this as a favor', 'success')
        history.push(`/profile`);

    } catch (err) {
        console.error(err.message);
        setIsLoading(false);
        // Display customised error message based on error title
        const errorMsg = err.response.data.msg
        if (errorMsg.includes("Requester")) {
            addNotification('Submission failed', 'Requester cannot complete their own request!', 'danger')
        } else if (errorMsg.includes("Reward")) {
            addNotification('Submission failed', 'You cannot complete a request with no reward!', 'danger')
        }
        else {
            addNotification('Submission failed', 'Please try again! Make sure you uploaded a valid photo', 'danger')
        }
    }
}
// Get completed requests


