import axios from 'axios';

// Get the list of all items
export const getItems = async (setItems) => {
    try {
        const res = await axios.get(`/api/items`);
        setItems(res.data)
    } catch (err) {
        console.error(err);
    }
}