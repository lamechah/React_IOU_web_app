import axios from 'axios';

// Get all the parties of the logged in user
export const getParties = async (setFavors, setIsParty) => {
    try {
        const res = await axios.get('/api/party');
        // If the user belongs to any party, store the favor data and set the Party flag to true
        if (res.data.length !== 0) {
            setFavors(res.data);
            setIsParty(true)
        }
    } catch (err) {
        console.error(err);
    }
}

// Get all favors that belong to the party
export const getPartyUser = async (favorid, partyid, setFavors) => {
    try {
        const res = await axios.get(`/api/party/${favorid}/${partyid}`);
        setFavors(res.data);
    } catch (err) {
        console.error(err);
    }
}

// Get all the users who belong to the party
export const getPartyFavor = async (id, setFavors, setIsParty) => {
    try {
        const res = await axios.get(`/api/party/${id}`);
        if (res.data.length !== 0) {
            setFavors(res.data);
            setIsParty(true)
        }
    } catch (err) {
        console.error(err);
    }
}
