import axios from 'axios';

// Get the profile of logged in user
export const getProfileUesr = async (setLoadedUser) => {
    try {
        const userResponse = await axios.get(`/api/profile/user`);
        setLoadedUser(userResponse.data.data.user);

    } catch (err) {
        console.error(err.message);
    }
}

// Get the number of completed favors that logged in user borrowed
// @retun   the  number of favors that the user repaid
export const getProfileCompletedFavorNo = async (setCompletedFavors) => {
    try {
        let count = 0;
        const favorResponse = await axios.get(`/api/profile/user/favors`);
        const completedFavors = favorResponse.data.data.favorBorrow;
        completedFavors.map((item) => {
            if (item.datecompleted !== null) {
                count++;
            }
            return count;
        });
        setCompletedFavors(count);
    } catch (err) {
        console.error(err.message);
    }
}

// Get the all favors that logged in user lent
export const getProfileFavorLent = async (setFavorsLent, setIsLoading) => {
    try {
        setIsLoading(true);
        const response = await axios.get(`/api/profile/user/favors`);
        setFavorsLent(response.data.data.favorLentByUser)
        setIsLoading(false)
    } catch (err) {
        console.error(err);
    }
}

// Get the all favors that logged in user borrowed
export const getProfileFavorBorrowed = async (setFavorsBorrowed, setIsLoading) => {
    try {
        setIsLoading(true);
        const response = await axios.get(`/api/profile/user/favors`);
        setFavorsBorrowed(response.data.data.favorBorrowedByUser);
        setIsLoading(false)
    } catch (err) {
        console.error(err);
    }
}

// Get the all requests that logged in user completed
export const getProfileRequestCompleted = async (setAcceptedRequests) => {
    try {
        const response = await axios.get(`/api/profile/user/myRequests`);
        setAcceptedRequests(response.data.data.requestAccepted);
    } catch (err) {
        console.error(err);
    }
}

// Get the all requests that logged in user created
export const getProfileRequestCreated = async (setMyRequests, setIsLoading) => {
    try {
        setIsLoading(true);
        const response = await axios.get(`/api/profile/user/myRequests`);
        setMyRequests(response.data.data.request);
        setIsLoading(false)
    } catch (err) {
        console.error(err);
    }

}

// Getting the transaction history of the user
export const getProfileHistory = async (setPeoplePaidHistory, setUserPaidHistory, setIsLoading) => {
    try {
        setIsLoading(true);
        const response = await axios.get(`/api/profile/user/history`);
        setPeoplePaidHistory(response.data.data.peoplePaid);    // transaction of favor that the user lent
        setUserPaidHistory(response.data.data.userPaid);    // transaction of favor that the user borrowed
        setIsLoading(false)
    } catch (err) {
        console.error(err);
    }

}




