import axios from 'axios';
import { addNotification } from '../components/shared/Utility/Alert';

// Get all rewards of a request
export const getRewards = async (id, setRewards) => {
    try {
        const res = await axios.get(`/api/rewards/${id}`);
        setRewards(res.data)
    } catch (err) {
        console.error(err);
    }
}

// Get total quantity of each reward of a request
export const getToTalRewardQty = async (id, setRewards) => {
    try {
        const res = await axios.get(`/api/rewards/${id}/total`);
        setRewards(res.data)
    } catch (err) {
        console.error(err);
    }

}

// Create a new reward
export const createReward = async (newReward, id, setRewards) => {
    try {
        // Set header and body
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const body = JSON.stringify(newReward);
        // Create a new rewards
        await axios.post(`/api/rewards/${id}`, body, config);
        const newList = await axios.get(`/api/rewards/${id}`);
        setRewards(newList.data)
        addNotification('Submission complete', 'The reward has been successfully added', 'success')
    } catch (err) {
        console.error(err);
        addNotification('Submission failed', 'Quantity must be a number that is greater than 0 and smaller than 21', 'danger')
    }
}

// Delete a reward
export const deleteReward = async (rewardid, history) => {
    try {
        await axios.delete(`/api/rewards/${rewardid}`);
        addNotification('Reward deleted', 'The reward is successfully deleted!', 'success')
        history.go(0);
    } catch (err) {
        console.error(err.message)
        addNotification('Reward failed to delete', 'You cannot delete the rewards of other people', 'danger')
    }
}