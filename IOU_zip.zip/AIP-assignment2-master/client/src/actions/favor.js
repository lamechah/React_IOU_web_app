import axios from 'axios';
import { addNotification } from "../components/shared/Utility/Alert";

// Create a new favor for lender
export const createFavorLender = async (newFavor, setIsLoading) => {
    try {
        // Set header and body
        const body = JSON.stringify(newFavor);
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        // Create a new favor as a lender
        const newPost = await axios.post(`/api/favors/lender`, body, config);
        const newPostId = newPost.data.data.user.favorid
        //  Trigger party detection upon successfully creating a new favor
        await axios.post(`/api/party/trigger`)
        return newPostId
    } catch (err) {
        console.error(err.message);
        setIsLoading(false);
    }

}

// Create a new favor for borrower
export const createFavorBorrower = async (newFavor, setIsLoading, history) => {
    try {
        // Set header and body
        const body = JSON.stringify(newFavor);
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        // Create a new favor as a borrower
        await axios.post(`/api/favors/borrower`, body, config);
        //  Trigger party detection upon successfully creating a new favor
        await axios.post(`/api/party/trigger`)
        addNotification('Submission completed', 'Favor is successfully added!', 'success');
        history.goBack();

    } catch (err) {
        console.error(err.message);
        setIsLoading(false);
        addNotification('Submission failed', 'Please try again', 'danger');
    }

}

// Get all the items for favor
export const getItems = async () => {
    try {
        const favorItem = await fetch(`/api/items/favorItems`);
        const body = await favorItem.json();
        return body;
    } catch (err) {
        console.error(err.message);
        addNotification('Submission failed', 'Please try again', 'danger')
    }
}

// Get all users
export const getUsers = async () => {
    try {
        const rawUser = await fetch(`/api/users`);
        const users = await rawUser.json();
        return users;
    } catch (err) {
        console.error(err.message);
        addNotification('Submission failed', 'Please try again', 'danger')
    }
}

// Get the logged in user
export const getLoggedUser = async () => {
    try {
        const response = await axios.get(`/api/profile/user`);
        const user = response.data.data.user.userid;
        return user;
    } catch (err) {
        console.error(err.message);
    }
}

// Repay the favor as borrower
export const repayFavorBorrower = async (id, setIsLoading, history) => {
    try {
        await axios.post(`/api/favors/borrower/complete/${id}`);
        addNotification(
            "Submission complete",
            "The favor has been completed! We have updated the favor",
            "success"
        );
        //redirects to the profile page
        history.push(`/profile`);
    } catch (err) {
        console.error(err);
        setIsLoading(false);
        addNotification('Submission failed', 'Please try again! Make sure you uploaded a valid photo', 'danger')
    }
}

// Repay the favor as lender
export const repayFavorLender = async (id, setIsLoading, history) => {
    try {
        await axios.post(`/api/favors/lender/complete/${id}`);
        addNotification(
            "Submission complete",
            "The favor has been completed! We have updated the favor",
            "success"
        );
        //redirects to the profile page
        history.push(`/profile`);
    } catch (err) {
        console.error(err);
        setIsLoading(false);
        addNotification('Submission failed', 'Please try again!', 'danger')
    }
}

// Get the detail of favor the user borrowed
export const getFavorDetailBorrowed = async (id, setUserFavor) => {
    try {
        const response = await axios.get(`/api/favors/user/${id}`);
        setUserFavor(response.data);
    } catch (err) {
        console.error(err);
    }
}

// Get the detail of favor the user lent
export const getFavorDetailLent = async (id, setFavor) => {
    try {
        const response = await axios.get(`/api/favors/people/${id}`);
        setFavor(response.data);
    } catch (err) {
        console.error(err);
    }
}

// Delete the favor
export const deleteFavor = async (id, history) => {
    try {
        await axios.delete(`/api/favors/${id}`);
        addNotification(
            "Favor deleted",
            "The favor has been deleted!",
            "success"
        );
        // Redirect to the profile page
        history.push(`/profile`);
    } catch (err) {
        console.error(err.message);
        addNotification("Favor deleted", "The favor cannot be deleted", "danger");
    }
}






