import axios from 'axios';

// Upload the photo
export const uploadFileLender = async (id, file) => {
    try {
        // Set form data
        const formData = new FormData();
        formData.append('photo', file);
        formData.append('type', 'requests');
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        };
        await axios.post(`/api/file/${id}`, formData, config);
    } catch (err) {
        console.error(err.message);
    }

}

export const uploadFileFavor = async (id, file) => {
    try {
        // Set form data
        const formData = new FormData();
        formData.append('photo', file);
        formData.append('type', 'favor');
        const config = {
            headers: {
                'content-type': 'multipart/form-data'
            }
        };
        await axios.post(`/api/file/${id}`, formData, config);
    } catch (err) {
        console.error(err.message);
    }

}
