import axios from 'axios';

// Get the ranking
// It returns two table:
// Table 1: Ranking by the number of favors given to other people
// Table 2: Ranking by the number of favors the user owes
export const getRanking = async () => {
    try {
        const res = await axios.get(`/api/ranking`)
        return res.data
    } catch (err) {
        console.error(err);
    }
}
