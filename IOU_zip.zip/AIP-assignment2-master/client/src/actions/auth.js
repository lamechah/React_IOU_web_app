import axios from 'axios';
import { addNotification } from '../components/shared/Utility/Alert';

// Check if the user is logged in
export const checkLogin = async (setIsLoggedIn) => {
    try {
        await axios.get(`/api/auth/check_login`)
        setIsLoggedIn(true)

    } catch (err) {
        console.error(err);
    }
}

// Get the logged in user id
export const getLoggedInUser = async () => {
    try {
        const res = await axios.get(`/api/auth/check_login`);
        return res.data.data.userid
    } catch (err) {
        console.error(err);
    }
}

// Log in
export const logIn = async (loginInformation, setIsLoading, history) => {
    try {
        // Set header and body
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const body = JSON.stringify(loginInformation);
        await axios.post('/api/auth/login', body, config);
        addNotification("Login completed", "You have been successfully logged in!", "success");
        history.go(0);

    } catch (err) {
        console.error(err);
        setIsLoading(false);
        // Display customised error message based on error title
        const errorTitle = err.response.data.errors[0].title;
        if (errorTitle === 'Email') {
            addNotification("Login error", "Email not found", "danger")
        } else if (errorTitle === 'Password') {
            addNotification("Login error", "Password does not match the email", "danger")
        } else {
            addNotification("Login error", "Login failed", "Please try again", "danger")
        }
    }
}

// Log out
export const logOut = async (history) => {
    try {
        await axios.get(`/api/auth/logout`)
        history.go(0);
    } catch (err) {
        console.error(err.message)
    }
}

// Register a new user
export const register = async (newUser, setIsLoading, history) => {
    try {
        // Set header and body
        const config = {
            headers: {
                'Content-Type': 'application/json'
            }
        }
        const body = JSON.stringify(newUser);

        // Register a new user
        await axios.post('/api/users', body, config);

        // If the user is successfully registered:
        // 1. Log in the new user automatically
        // 2. Take the user to the profile page
        const userInfo = {
            'email': newUser.email,
            'passwords': newUser.passwords
        }
        // Set the body
        const loginInfo = JSON.stringify(userInfo)
        await axios.post('/api/auth/login', loginInfo, config);
        addNotification("Registration complete", "You have been successfully registered!", "success")
        history.go(0);

    } catch (err) {
        console.log(err.message)
        setIsLoading(false);
        // Display customised error message based on error title or message
        const errorMsg = err.response.data.errors[0].msg
        if (errorMsg.includes('email')) {
            errorMsg.includes('valid') ? addNotification("Email not valid", "Please check the email again", "danger")
                : addNotification("Email already exists", "Please try another email", "danger")
        } else if (errorMsg.includes('Username')) {
            errorMsg.includes('English') ? addNotification("Username not valid", "Username should be between 3 and 20 characters in English", "danger")
                : addNotification("Username already exists", "Please try another username", "danger")
        } else if (errorMsg.includes('password')) {
            addNotification("Password not valid", "Password should be between 6 and 128 characters", "danger")
        } else {
            addNotification("Registration failed", "Please try again", "danger")
        }
    }

}