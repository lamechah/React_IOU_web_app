import React, { useState, useEffect, Fragment } from 'react'
import { withRouter } from 'react-router-dom';
import { checkLogin } from '../../actions/auth';
import { deleteReward } from '../../actions/reward';

import './RewardItem.css';

const RewardItem = ({ rewardid, item, quantity, user, history }) => {
    let [isLoggedIn, setIsLoggedIn] = useState(false)
    // Check if a user is logged in
    useEffect(() => {
        async function fetchData() {
            await checkLogin(setIsLoggedIn);
        };
        fetchData();
    }, [isLoggedIn]);

    const onClick = async () => {
        // Delete the reward
        await deleteReward(rewardid, history);
    }

    return (
        <Fragment>
            <tr>
                <td className="rewardItem-td">{item}</td>
                <td className="rewardItem-td">{quantity}</td>
                <td className="rewardItem-td">{user}</td>
                {/* If the user is logged in, display delete button */}
                {isLoggedIn && <td><button className='request-delete-btn' onClick={() => onClick()}>Delete</button></td>}
            </tr>
        </Fragment>
    );

}

export default withRouter(RewardItem);
