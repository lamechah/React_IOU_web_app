import React, { useState, useEffect, Fragment } from 'react'
import { useParams } from 'react-router-dom';
import RewardItem from './RewardItem';
import RewardForm from './RewardForm';
import Pagination from '../shared/Utility/Pagination';
import { getRewards } from "../../actions/reward";
import { checkLogin } from "../../actions/auth";


import './Rewards.css';

const Rewards = ({ displayRewardsForm }) => {
    const { id } = useParams();

    const [rewards, setRewards] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [rewardsPerPage] = useState(10);
    let [isLoggedIn, setIsLoggedIn] = useState(false)

    // Get the list of rewards of a request
    // Check if the user is logged in
    useEffect(() => {
        async function fetchData() {
            await getRewards(id, setRewards);
            await checkLogin(setIsLoggedIn)
        };
        fetchData();
    }, [id, isLoggedIn]);

    // Get current requests for pagination
    const lastReward = currentPage * rewardsPerPage;
    const firstReward = lastReward - rewardsPerPage;
    const currentList = rewards.slice(firstReward, lastReward);

    // Change page
    const paginate = pageNumber => setCurrentPage(pageNumber);

    // Get the current rewards list
    const currentRewards = currentList.map(reward => (
        <RewardItem
            key={reward.rewardid}
            rewardid={reward.rewardid}
            item={reward.itemname}
            quantity={reward.quantity}
            user={reward.username}
            userid={reward.userid} />
    ))

    return (
        <Fragment>
            <hr />
            <div className="reward-h3">Current Rewards</div>
            <table className="reward-table">
                <thead>
                    <tr className="reward-tr">
                        <th className="reward-th">Item</th>
                        <th className="reward-th">Quantity</th>
                        <th className="reward-th">Rewarder</th>
                        {isLoggedIn && <th className="reward-th">Action</th>}
                    </tr>
                </thead>
                {/* Display current requests */}
                <tbody>{currentRewards}</tbody>
            </table>
            <Pagination
                itemsPerPage={rewardsPerPage}
                totalItems={rewards.length}
                paginate={paginate} />
            <hr />
            {displayRewardsForm && <RewardForm setRewards={setRewards} />}
        </Fragment>
    )
}


export default Rewards
