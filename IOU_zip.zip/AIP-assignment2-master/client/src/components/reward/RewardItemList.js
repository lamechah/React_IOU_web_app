import React, { useState, useEffect, Fragment } from 'react'
import { getToTalRewardQty } from '../../actions/reward';

import './RewardItemList.css';

const RewardItemList = (requestid) => {

    const id = requestid.requestid

    const [rewards, setRewards] = useState([]);

    // Get the total quantity of each reward of a request
    useEffect(() => {
        async function fetchData() {
            await getToTalRewardQty(id, setRewards)
        };
        fetchData();
    }, [id]);

    return (
        <Fragment>
            <div className='rewardItemList-container'>
                {rewards.map((reward, index, { length }) => (
                    index + 1 !== length ? `${reward.itemname} x ${reward.total}, ` : `${reward.itemname} x ${reward.total}`
                ))}
            </div>
        </Fragment>
    )
}


export default RewardItemList