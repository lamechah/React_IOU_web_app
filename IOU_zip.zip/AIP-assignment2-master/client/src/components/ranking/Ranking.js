import React from 'react';
import './Ranking.css';
import { Table } from 'react-bootstrap';
import { getRanking } from '../../actions/ranking';

class Ranking extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      return_data: {
        table1: [],
        table2: []
      }
    };
  }
  componentDidMount() {
    try {
      getRanking().then(rankings => {
        this.setState({
          return_data: {
            // Table 1: Ranking by the number of favors given to other people
            // Table 2: Ranking by the number of favors the user owes
            table1: rankings.table1.rows,
            table2: rankings.table2.rows
          }
        });
      }
      )
    } catch (err) {
      console.error(err.message);
    }
  }

  render() {
    const { return_data } = this.state;
    return (
      <div className='ranking-container'>
        <h1>User Ranking </h1>
        <br></br>
        <h5>Check out the top 10 lenders and the top 10 borrowers! </h5>
        <br></br>
        <h3>Top lenders</h3>
        <Table striped bordered hover >
          <thead>
            <tr>
              <th>Username</th>
              <th>Favors given</th>
            </tr>
          </thead>
          {/* Display Table 1 */}
          {return_data.table1.map((item, index) => (
            <tbody key={index}>
              <tr>
                <td>{item.user}</td>
                <td>{item.total_favors_given}</td>
              </tr>
            </tbody>
          ))}
        </Table>
        <br></br>
        <h3>Top borrowers</h3>
        <Table striped bordered hover >
          <thead>
            <tr>
              <th>Username</th>
              <th>Favors received</th>
            </tr>
          </thead>
          {/* Display Table 2 */}
          {return_data.table2.map((item, index) => (
            <tbody key={index}>
              <tr>
                <td>{item.user}</td>
                <td>{item.total_favors_received}</td>
              </tr>
            </tbody>
          ))}
        </Table>
      </div>
    );
  }
}

export default Ranking;