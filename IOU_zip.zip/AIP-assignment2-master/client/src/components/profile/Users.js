import React, { useEffect, useState } from "react";
import UserprofileItem from "./UserProfileItem";
import UserOwesStats from "./UserOwesStats";
import PeopleOwes from "./PeopleOwes";
import UserRequests from "./UserRequests";
import RequestsAccepted from "./RequestsAccepted";
import History from "./History";
import PartyNotice from "../party/PartyNotice";
import { getProfileUesr, getProfileCompletedFavorNo } from '../../actions/profile';

import "./Users.css";
import profileImg from '../../image/profile_default.jpg';

const Users = () => {
  const [loadedUser, setLoadedUser] = useState("");
  const [loadCompletedFavors, setCompletedFavors] = useState([]);
  const [displayContent, setDisplayContent] = useState(<UserOwesStats />);

  // Get user details using userid
  useEffect(() => {
    async function fetchUser() {
      await getProfileUesr(setLoadedUser);
      await getProfileCompletedFavorNo(setCompletedFavors);
    }
    fetchUser();
  }, []);

  // Display different contents based on the button the user clicks
  const displayItem = (type) => {
    switch (type) {
      case "iowe":
        setDisplayContent(<UserOwesStats />);
        break;
      case 'peopleowe':
        setDisplayContent(<PeopleOwes />)
        break;
      case 'myRequests':
        setDisplayContent(<UserRequests />)
        break;
      case 'requestsAccepted':
        setDisplayContent(<RequestsAccepted />)
        break;
      case 'history':
        setDisplayContent(<History />)
        break;
      default:
        setDisplayContent(<UserOwesStats />);
    }
  }

  return (
    <React.Fragment>
      <PartyNotice />
      <div>
        {/* Left hand Profile Card of the user */}
        <ul className="user-list">
          <UserprofileItem
            userid={loadedUser.userid}
            username={loadedUser.username}
            image={profileImg}
            favors={loadCompletedFavors + " favors repaid"}
          />
        </ul>
      </div>
      {/* Display buttons */}
      <div>
        <ul className="profile-navigation">
          <li>
            <button onClick={() => displayItem("iowe")}>What I Owe</button>
          </li>
          <li>
            <button onClick={() => displayItem("peopleowe")}>What People Owe Me</button>
          </li>
          <li>
            <button onClick={() => displayItem("myRequests")}>My Requests</button>
          </li>
          <li>
            <button onClick={() => displayItem("requestsAccepted")}>Request Accepted</button>
          </li>
          <li>
            <button onClick={() => displayItem("history")}>Transaction History</button>
          </li>
        </ul>
        {/* Display contents */}
        <div>{displayContent}</div>
      </div>
    </React.Fragment>
  );
};

export default Users;
