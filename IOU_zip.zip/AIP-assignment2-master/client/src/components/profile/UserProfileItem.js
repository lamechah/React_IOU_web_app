import React from "react";
import Card from "../shared/UIElements/Card";
import Avatar from "../shared/UIElements/Avatar";

import Button from "../shared/UIElements/Button";
import "./UserProfileItem.css";

//setting the user profile data
const UserProfileItem = (props) => {
  return (
    <React.Fragment>
      <li className="user-item">
        <Card className="user-item__content">
          <div className="user-item__image">
            <Avatar image={props.image} alt={props.username} />
          </div>
          <div className="user-item__info">{props.username}</div>
          <div className="user-item__favors">{props.favors}</div>
          <div className="button-items">
            <Button to="/create-favor">+ New Favor</Button>
            <Button to="/create-request">+ New Request</Button>
          </div>
        </Card>
      </li>
    </React.Fragment>
  );
};

export default UserProfileItem;
