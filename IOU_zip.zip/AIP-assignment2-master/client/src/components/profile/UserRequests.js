import React, { useEffect, useState } from "react";
import Button from '../shared/UIElements/Button';
import Pagination from "../shared/Utility/Pagination";
import RewardItemList from "../reward/RewardItemList";
import Spinner from '../shared/Utility/Spinner';
import { getProfileRequestCreated } from '../../actions/profile';

import "./Users.css";
import { withRouter } from "react-router-dom";

const UserRequests = () => {
  const [loadMyRequests, setMyRequests] = useState([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [requestsPerPage] = useState(10);
  let [isLoading, setIsLoading] = useState(false);

  // Getting data of the users for the requests created by him
  useEffect(() => {
    async function fetchRequests() {
      await getProfileRequestCreated(setMyRequests, setIsLoading)
    }
    fetchRequests();
  }, []);

  // Get current requests for pagination
  const lastRequest = currentPage * requestsPerPage;
  const firstRequest = lastRequest - requestsPerPage;
  const currentList = loadMyRequests.slice(firstRequest, lastRequest);

  // Change page
  const paginate = pageNumber => setCurrentPage(pageNumber);

  return (
    isLoading ? <Spinner /> :
      <div>
        {/* Display the list of request, only if there is any request that the user created */}
        {loadMyRequests.length === 0 ? (
          <React.Fragment>
            <h3 className="message-myrequest">
              No available requests. You want to create one?
          </h3>
            <p className="new-favor">
              <Button className="newbutton" to="/create-request">+ New Request</Button>
            </p>
          </React.Fragment>
        ) : (
            <React.Fragment>
              <div>
                <table className="stats">
                  <thead>
                    <tr>
                      <th>Request</th>
                      <th>Reward</th>
                    </tr>
                  </thead>
                  {currentList.map((item, index) => {
                    return (
                      <tbody key={index}>
                        <tr>
                          <td>{item.task}</td>
                          <td><RewardItemList requestid={item.requestid} /></td>
                          <td>
                            <Button to={`/request/${item.requestid}`}>See More</Button>
                          </td>
                        </tr>
                      </tbody>
                    );
                  })}
                </table>
                <div className='profile-pagination'>
                  <Pagination
                    itemsPerPage={requestsPerPage}
                    totalItems={loadMyRequests.length}
                    paginate={paginate} />
                </div>
              </div>

            </React.Fragment>
          )}
      </div>
  );
};
export default withRouter(UserRequests);
