import React, { useEffect, useState } from "react";
import Button from '../shared/UIElements/Button';
import Pagination from "../shared/Utility/Pagination";
import Spinner from '../shared/Utility/Spinner';
import { getProfileFavorBorrowed } from '../../actions/profile';

import "./Users.css";

const UserOwesStats = () => {
  const [loadFavorsBorrowed, setFavorsBorrowed] = useState([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [favorsPerPage] = useState(10);
  let [isLoading, setIsLoading] = useState(false);

  // Getting user data for the favors he owe
  useEffect(() => {
    async function fetchFavorsBorrowed() {
      await getProfileFavorBorrowed(setFavorsBorrowed, setIsLoading);
    }
    fetchFavorsBorrowed();
  }, []);

  // Get current favors for pagination
  const lastFavor = currentPage * favorsPerPage;
  const firstFavor = lastFavor - favorsPerPage;
  const currentList = loadFavorsBorrowed.slice(firstFavor, lastFavor);

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    isLoading ? <Spinner /> :
      <div>
        {/* Display the list of favor, only if there is any favor that the user owes */}
        {loadFavorsBorrowed.length === 0 ? (
          <React.Fragment>
            <h3 className="message-userowe">You don't owe anyone a favor.</h3>
          </React.Fragment>
        ) : (
            <React.Fragment>
              <table className="stats">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Who I Owe?</th>
                    <th> What I Owe?</th>
                  </tr>
                </thead>
                {currentList.map((item, index) => {
                  return (
                    <tbody key={index}>
                      <tr>
                        <td>{item.favorid}</td>
                        <td>{item.username}</td>
                        <td>
                          {item.quantity} x {item.itemname}
                        </td>
                        <td>
                          <Button to={`/favor/user/${item.favorid}`}>
                            See More
                      </Button>
                        </td>
                      </tr>
                    </tbody>
                  );
                })}
              </table>
              <div className="profile-pagination">
                <Pagination
                  itemsPerPage={favorsPerPage}
                  totalItems={loadFavorsBorrowed.length}
                  paginate={paginate}
                />
              </div>
            </React.Fragment>
          )}
      </div>
  );
};

export default UserOwesStats;
