import React, { useEffect, useState } from "react";
import Button from '../shared/UIElements/Button';
import Pagination from "../shared/Utility/Pagination";
import Spinner from '../shared/Utility/Spinner';
import { getProfileFavorLent } from '../../actions/profile';

import "./Users.css";

const PeopleOwes = () => {
  const [loadFavorsLent, setFavorsLent] = useState([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [favorsPerPage] = useState(10);
  let [isLoading, setIsLoading] = useState(false);

  // Getting user data for the favors owed by people
  useEffect(() => {
    async function fetchFavorsLent() {
      await getProfileFavorLent(setFavorsLent, setIsLoading)
    }
    fetchFavorsLent();
  }, []);

  // Get current favors for pagination
  const lastFavor = currentPage * favorsPerPage;
  const firstFavor = lastFavor - favorsPerPage;
  const currentList = loadFavorsLent.slice(firstFavor, lastFavor);

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    isLoading ? <Spinner /> :
      <div>
        {/* Display the list of favor, only if there is any favor */}
        {loadFavorsLent.length === 0 ? (
          <React.Fragment>
            <h3 className="message-peopleowe">
              It seems thats no one owes you a favor. Why don't you create a new
              favor?
          </h3>
            <p className="new-favor">
              <Button to="/create-favor" className="newbutton">
                + New Favor
            </Button>
            </p>
          </React.Fragment>
        ) : (
            <React.Fragment>
              <table className="stats">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Who Owe Me?</th>
                    <th> What They Owe?</th>
                  </tr>
                </thead>
                {currentList.map((item, index) => {
                  return (
                    <tbody key={index}>
                      <tr>
                        <td>{item.favorid}</td>
                        <td>{item.username}</td>
                        <td>
                          {item.quantity} x {item.itemname}
                        </td>
                        <td>
                          <Button to={`/favor/people/${item.favorid}`}>
                            See More
                      </Button>
                        </td>
                      </tr>
                    </tbody>
                  );
                })}
              </table>
              <div className="profile-pagination">
                <Pagination
                  itemsPerPage={favorsPerPage}
                  totalItems={loadFavorsLent.length}
                  paginate={paginate}
                />
              </div>
            </React.Fragment>
          )}
      </div>
  );
};

export default PeopleOwes;
