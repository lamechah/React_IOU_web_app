import React, { Fragment, useEffect, useState } from "react";
import Pagination from "../shared/Utility/Pagination";
import Spinner from '../shared/Utility/Spinner';
import { getProfileHistory } from '../../actions/profile';
import "./Users.css";

const History = () => {
  const [loadPeoplePaidHistory, setPeoplePaidHistory] = useState([]);
  const [loadUserPaidHistory, setUserPaidHistory] = useState([]);

  const [currentPageOfPeople, setCurrentPageOfPeople] = useState(1);
  const [currentPageOfUser, setCurrentPageOfUser] = useState(1);
  const [itemsPerPage] = useState(5);
  let [isLoading, setIsLoading] = useState(false);

  // Getting the transaction history of the user
  useEffect(() => {
    async function fetchHistoryData() {
      await getProfileHistory(setPeoplePaidHistory, setUserPaidHistory, setIsLoading);
    }
    fetchHistoryData();
  }, []);

  // Get history of favors people owe to user
  const lastPeopleHistory = currentPageOfPeople * itemsPerPage;
  const firstPeopleHistory = lastPeopleHistory - itemsPerPage;
  const currentListOfPeople = loadPeoplePaidHistory.slice(
    firstPeopleHistory,
    lastPeopleHistory
  );

  // Get history of favors user owes to people
  const lastUserHistory = currentPageOfUser * itemsPerPage;
  const firstUserHistory = lastUserHistory - itemsPerPage;
  const currentListOfUser = loadUserPaidHistory.slice(
    firstUserHistory,
    lastUserHistory
  );
  // Change page
  const paginationOfPeople = (pageNumber) => setCurrentPageOfPeople(pageNumber);
  const paginationOfUser = (pageNumber) => setCurrentPageOfUser(pageNumber);

  return (
    isLoading ? <Spinner /> :
      <div>
        {/* History of favors that other people paid to the user */}
        <h3 className="message-history">People Paid You</h3>
        {/* Display the list of transaction, only if there is any transaction */}
        {loadPeoplePaidHistory.length === 0 ? (
          <h4 className="message-history">No History Available</h4>
        ) : (
            <Fragment>
              <div>
                <table className="history-stats">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>User</th>
                      <th>Reward</th>
                    </tr>
                  </thead>
                  {currentListOfPeople.map((item, index) => {
                    return (
                      <tbody key={index}>
                        <tr>
                          <td className="history-stats-body">{item.favorid}</td>
                          <td className="history-stats-body">{item.username}</td>
                          <td className="history-stats-body">
                            {item.quantity} x {item.itemname}
                          </td>
                          {/* <td>
                        <Button to={`/history/${item.favorid}`}>
                          See More
                        </Button>
                      </td> */}
                        </tr>
                      </tbody>
                    );
                  })}
                </table>
                <div className="profile-pagination">
                  <Pagination
                    itemsPerPage={itemsPerPage}
                    totalItems={loadPeoplePaidHistory.length}
                    paginate={paginationOfPeople}
                  />
                </div>
              </div>
            </Fragment>
          )}

        {/* History of favors that the user paid to others */}
        <h3 className="message-history">You Paid</h3>
        {/* Display the list of transaction, only if there is any transaction */}
        {loadUserPaidHistory.length === 0 ? (
          <h4 className="message-history">No History Available</h4>
        ) : (
            <Fragment>
              <div>
                <table className="history-stats">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>User</th>
                      <th>Reward</th>
                    </tr>
                  </thead>
                  {currentListOfUser.map((item, index) => {
                    return (
                      <tbody key={index}>
                        <tr>
                          <td className="history-stats-body">{item.favorid}</td>
                          <td className="history-stats-body">{item.username}</td>
                          <td className="history-stats-body">
                            {item.quantity} x {item.itemname}
                          </td>
                        </tr>
                      </tbody>
                    );
                  })}
                </table>
                <div className="profile-pagination">
                  <Pagination
                    itemsPerPage={itemsPerPage}
                    totalItems={loadUserPaidHistory.length}
                    paginate={paginationOfUser}
                  />
                </div>
              </div>
            </Fragment>
          )}
      </div>
  );
};
export default History;
