import React, { useEffect, useState } from "react";
import Pagination from "../shared/Utility/Pagination";
import RewardItemList from "../reward/RewardItemList";
import { getProfileRequestCompleted } from '../../actions/profile';

import "./Users.css";

const RequestsAccepted = () => {
  const [loadAcceptedRequests, setAcceptedRequests] = useState([]);

  const [currentPage, setCurrentPage] = useState(1);
  const [requestsPerPage] = useState(10);

  //Getting the data for requests accepted by the user
  useEffect(() => {
    async function fetchAccpetedRequests() {
      await getProfileRequestCompleted(setAcceptedRequests);
    }
    fetchAccpetedRequests();
  }, []);

  // Get current requests for pagination
  const lastRequest = currentPage * requestsPerPage;
  const firstRequest = lastRequest - requestsPerPage;
  const currentList = loadAcceptedRequests.slice(firstRequest, lastRequest);

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div>
      {/* Display the list of requests, only if there is any request that the user accepted */}
      {loadAcceptedRequests.length === 0 ? (
        <React.Fragment>
          <h3 className="message-acceptedRequest">No Requests Accepted.</h3>
        </React.Fragment>
      ) : (
          <React.Fragment>
            <table className="requestaccepted-stats">
              <thead>
                <tr>
                  <th>Who Asked</th>
                  <th>Description</th>
                  <th>Reward</th>
                </tr>
              </thead>
              {currentList.map((item, index) => {
                return (
                  <tbody key={index}>
                    <tr>
                      <td>{item.username}</td>
                      <td>{item.task}</td>
                      <td>
                        <RewardItemList requestid={item.requestid} />
                      </td>
                    </tr>
                  </tbody>
                );
              })}
            </table>
            <div className="profile-pagination">
              <Pagination
                itemsPerPage={requestsPerPage}
                totalItems={loadAcceptedRequests.length}
                paginate={paginate}
              />
            </div>
          </React.Fragment>
        )}
    </div>
  );
};
export default RequestsAccepted;
