import { withRouter } from 'react-router-dom';
import { logOut } from '../../actions/auth'

// Log out the user
const Logout = async ({ history }) => {
    await logOut(history)
}

export default withRouter(Logout)
