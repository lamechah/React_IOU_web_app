import React, { Fragment, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { withRouter, Redirect } from 'react-router-dom';
import Spinner from '../shared/Utility/Spinner';
import { checkLogin, logIn } from '../../actions/auth'

import "./auth.css";
import Button from '../shared/UIElements/Button'

const Login = ({ history }) => {
    // Flag for checking if the user is logged in
    let [isLoggedIn, setIsLoggedIn] = useState(false);
    // Flag for checking if the application is loading
    let [isLoading, setIsLoading] = useState(false);

    const [formData, setFormData] = useState({
        email: '',
        passwords: '',
    });

    // Check if user is logged in.
    useEffect(() => {
        async function fetchData() {
            await checkLogin(setIsLoggedIn);
        };
        fetchData();
    }, []);

    // Redirect if logged in
    if (isLoggedIn) {
        return <Redirect to='/profile' />;
    }

    const { email, passwords } = formData;

    const onChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const onSubmit = async e => {
        e.preventDefault();
        setIsLoading(true);
        const loginInformation = {
            email,
            passwords
        }
        // Log in the user
        await logIn(loginInformation, setIsLoading, history);
    };

    return (
        isLoading ? <Spinner /> :
            <Fragment>
                <div className="register-container">
                    <h1>LOGIN</h1>
                    <div>
                        <form className='login-form-container' onSubmit={e => onSubmit(e)}>
                            <div className="register-form">
                                <label>Email<span>*</span></label>
                                <input type="email" name="email" value={email} onChange={e => onChange(e)} data-name="Email" required />
                                <label>Password<span>*</span></label>
                                <input type="password" name="passwords" value={passwords} onChange={e => onChange(e)} required />
                                <Button variant="primary" type="submit">Submit</Button>
                            </div>
                        </form>
                        <div>Do not have an account? <Link className='login-to-register-btn' to='/register'>Register</Link></div>
                    </div>
                </div>
            </Fragment>
    )
};


export default withRouter(Login);