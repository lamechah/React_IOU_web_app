import React, { Fragment, useState, useEffect } from 'react';
import { withRouter, Redirect } from 'react-router-dom';
import { addNotification } from '../shared/Utility/Alert';
import Spinner from '../shared/Utility/Spinner';
import { checkLogin, register } from '../../actions/auth'

import "./auth.css";
import Button from '../shared/UIElements/Button'

const Register = ({ history }) => {
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        passwords: '',
        passwordConfirm: '',
    });
    // Flag for checking if the user is logged in
    let [isLoggedIn, setIsLoggedIn] = useState(false)
    // Flag for checking if the application is loading
    let [isLoading, setIsLoading] = useState(false);

    const { username, email, passwords, passwordConfirm } = formData;

    // Check if user is logged in.
    useEffect(() => {
        async function fetchData() {
            checkLogin(setIsLoggedIn);
        };
        fetchData();
    }, []);

    // Redirect if logged in
    if (isLoggedIn) {
        return <Redirect to='/profile' />;
    }


    const onChange = e =>
        setFormData({ ...formData, [e.target.name]: e.target.value });

    const onSubmit = async e => {
        e.preventDefault();
        // If the password does not match, display warning message
        if (passwords !== passwordConfirm) {
            console.log('Password do not match')
            addNotification("Registration failed", "Password does not match", "danger")
        } else {
            // Register a new user
            const newUser = {
                username,
                email,
                passwords
            }
            setIsLoading(true);
            await register(newUser, setIsLoading, history);
        }
    };

    return (
        isLoading ? <Spinner /> :
            <Fragment>
                <div className="register-container">
                    <h1>SIGN UP</h1>
                    <div className='register-warning'><span>*</span> indicates required field</div>
                    <div>
                        <form className='register-form-container' onSubmit={e => onSubmit(e)}>
                            <div className="register-form">
                                <label>Username<span>*</span></label>
                                <div className='register-warning'>Username should be between 3 and 20 characters in English</div>
                                <input type="text" name="username" value={username} onChange={e => onChange(e)} required />
                                <label>Email address<span>*</span></label>
                                <input type="email" name="email" value={email} onChange={e => onChange(e)} data-name="Email" required />
                                <label>Password<span>*</span></label>
                                <div className='register-warning'>Password should be between 6 and 128 characters</div>
                                <input type="password" name="passwords" value={passwords} onChange={e => onChange(e)} required />
                                <label>Confirm password<span>*</span></label>
                                <input type="password" name="passwordConfirm" value={passwordConfirm} onChange={e => onChange(e)} required />
                                <Button variant="primary" type="submit">Submit</Button>
                            </div>
                        </form>
                    </div>
                </div>
            </Fragment>
    )
};


export default withRouter(Register);
