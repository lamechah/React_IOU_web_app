import React, { useState, useEffect } from 'react';
import { getPartyUser } from "../../actions/partyDetection";

import './PartyList.css';

const PartyItem = (partyid, favorid) => {
    const [favors, setFavors] = useState([]);

    // Get all users related to the party
    useEffect(() => {
        async function fetchData() {
            await getPartyUser(favorid, partyid.partyid, setFavors);
        };
        fetchData();
    }, [partyid.partyid, favorid])

    // Display all the people involved in the party
    return (
        <div className='party-list-item'>People who are in this Party:
            {favors.map((favor, index, { length }) => (
                index + 1 !== length ? ` ${favor.username}, ` : ` ${favor.username}`
            )
            )}
        </div>
    )
}



export default PartyItem
