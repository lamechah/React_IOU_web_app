import React, { Fragment, useState, useEffect } from 'react';
import Modal from "react-modal";
import { getParties } from "../../actions/partyDetection";

import Button from "../shared/UIElements/Button";
import './PartyNotice.css';

const PartyDetection = () => {

    const [favors, setFavors] = useState([]);
    const [isParty, setIsParty] = useState(false);  // Simple check if the user belongs to any party
    const [displayParty, toggleParty] = useState(true);
    const [modalIsOpen, setModalIsOpen] = useState(false);

    // Get all parties of the logged in user
    useEffect(() => {
        async function fetchData() {
            await getParties(setFavors, setIsParty)
        };
        fetchData();
    }, [])

    return (
        isParty && displayParty && <Fragment>
            <div className='party-container'>
                <div className="party-close-btn" onClick={() => toggleParty(!displayParty)}><i className="far fa-times-circle fa-2x"></i></div>
                <h3>Party Detected! <i className="far fa-question-circle" onClick={() => setModalIsOpen(true)}></i></h3>
                {/* Simple explanation of what Party is */}
                <Modal
                    isOpen={modalIsOpen}
                    onRequestClose={() => setModalIsOpen(false)}
                    style={
                        {
                            overlay: { backgroundColor: "grey" }
                        }}>
                    <div>
                        <div className="party-modal">
                            <h1>What is Party?</h1>
                            <div className="party-modal-content">
                                Party refers to a <span>cycle of users.</span><br />
                                For example, Alice owes Bobby a coffee, Bobby owes Carol a coffee, Carol owes Greg a coffee and Greg owes Alice a coffee.<br />
                                Then, there is a cycle between Alice, Bobby, Carol, and Greg.<br />
                                Everyone in the party can get together to clear all the debts at once.<br />
                                <span>If anyone in the Party repays the debt, the cycle will be broken and there will be no more cycle.</span>
                            </div>
                        </div>
                        <div className="close-btn">
                            <Button onClick={() => setModalIsOpen(false)}>Close</Button>
                        </div>
                    </div>
                </Modal>
                <div>
                    {favors.map((favor) => (
                        <div className='party-item' key={favor.favorid}>
                            - Please check the favor with id of <span>{favor.favorid}</span> for party id of <span>{favor.partyid}</span>
                        </div>))}
                </div>
            </div>
        </Fragment>
    )
}

export default PartyDetection
