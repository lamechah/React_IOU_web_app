import React, { Fragment, useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getPartyFavor } from "../../actions/partyDetection";
import PartyItem from './PartyItem'

import './PartyList.css';

const PartyList = () => {
    const { id } = useParams();

    const [favors, setFavors] = useState([]);
    const [isParty, setIsParty] = useState(false);
    const [displayParty, toggleParty] = useState(true);

    // Get all the favors related to the party
    useEffect(() => {
        async function fetchData() {
            await getPartyFavor(id, setFavors, setIsParty);
        };
        fetchData();
    }, [id])

    return (isParty && displayParty &&
        <Fragment>
            <div className='party-list-container'>
                <div className="party-close-btn" onClick={() => toggleParty(!displayParty)}><i className="far fa-times-circle fa-2x"></i></div>
                <h3>Party list</h3>
                <div className='party-list'>
                    {favors.map((favor) => (
                        <div key={favor.favorid}>
                            <div className='party-list'>
                                - Party no. <span>{favor.partyid}</span>
                            </div>
                            <PartyItem key={favor.favorid} partyid={favor.partyid} favorid={favor.favorid} />
                        </div>
                    )
                    )}
                </div>
            </div>
        </Fragment>
    )
}

export default PartyList
