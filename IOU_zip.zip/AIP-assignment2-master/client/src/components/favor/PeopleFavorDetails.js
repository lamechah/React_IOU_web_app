import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Moment from "react-moment";
import { addNotification } from "../shared/Utility/Alert";
import FavorCompletion from "../favor-form/FavorCompletion";
import PartyList from "../party/PartyList";
import { getFavorDetailLent, deleteFavor } from '../../actions/favor';

import "./FavorDetails.css";
import Button from "../shared/UIElements/Button";
import Modal from "react-modal";
Modal.setAppElement("#root");

const PeopleFavorDetails = ({ history }) => {
  const { id } = useParams();
  const [loadFavor, setFavor] = useState("");
  const [displayCompletionForm, toggleCompletionForm] = useState(false);
  const [modalIsOpen, setModalIsOpen] = useState(false);

  // Get the favor detail
  useEffect(() => {
    async function fetchData() {
      await getFavorDetailLent(id, setFavor);
    }
    fetchData();
  }, [id]);

  // Delete the favor on click
  const deleteFavorClick = async () => {
    const confirm = window.confirm("Are you sure you want to delete favor?");
    if (confirm === true) {
      await deleteFavor(id, history);
    }
  };

  // If there is no proof (photo) applicable for the favor, display warning message
  const noProof = () => {
    addNotification("No Proof", "There is no proof available", "danger");
  };

  return (
    <div className="favor-container">
      <PartyList />
      <Button to="/profile">Back to Profile</Button>
      <div className="favor-delete">
        <Button onClick={() => deleteFavorClick()}>Delete Favor</Button>
      </div>
      <div className="favor-item">
        <h1>Favor: #{loadFavor.favorid}</h1>
        <div>Borrower: {loadFavor.username}</div>
        <div>
          Date Created:
          <Moment format="YYYY/MM/DD">{loadFavor.datecreated}</Moment>
        </div>
        <hr />
        <h3>
          Favor: {loadFavor.quantity} x {loadFavor.itemname}
        </h3>
      </div>
      {/* Display the Favor Completion form if the user clicks the button */}
      <div className="favor-complete">
        <Button onClick={() => toggleCompletionForm(!displayCompletionForm)}>
          Complete Favor
        </Button>
      </div>
      {/* 
          If there is photo, display the photo in a modal.
          If not, display warning message
       */}
      {loadFavor.photo !== null ? (
        <div className="favor-view">
          <Button onClick={() => setModalIsOpen(true)}>View Proof</Button>
          <Modal
            isOpen={modalIsOpen}
            onRequestClose={() => setModalIsOpen(false)}
            style={{
              overlay: {
                backgroundColor: "grey",
              },
            }}
          >
            <div>
              <div className="image-container">
                <img src={loadFavor.photo} alt="favor-proof" />
              </div>
              <div className="close-btn">
                <Button onClick={() => setModalIsOpen(false)}>Close</Button>
              </div>
            </div>
          </Modal>
        </div>
      ) : (
          <div className="favor-view">
            <Button onClick={() => noProof()}>View Proof</Button>
          </div>
        )}
      <div>{displayCompletionForm && <FavorCompletion user={loadFavor} />}</div>
    </div>
  );
};

export default PeopleFavorDetails;
