import React, { useState, Fragment } from 'react'
import { withRouter } from 'react-router-dom';
import Spinner from '../shared/Utility/Spinner';
import { createRequest } from '../../actions/request';

import './NewRequest.css';
import '../shared/UIElements/Button'
import '../../../node_modules/react-notifications-component/dist/theme.css'

const NewRequest = ({ history }) => {
    const [formData, setFormData] = useState({
        task: '',
    });

    let [isLoading, setIsLoading] = useState(false);

    const { task } = formData;

    const onChange = e =>
        setFormData({ ...formData, [e.target.name]: e.target.value });

    const onSubmit = async e => {
        e.preventDefault();
        setIsLoading(true);
        const newRequest = {
            task
        }
        // Create a new Request
        await createRequest(newRequest, setIsLoading, history);
    };

    return (
        isLoading ? <Spinner /> :
            <Fragment>
                <div className="request-container">
                    <h1>Post a request</h1>
                    <div>
                        <div>Describe the task<span>*</span></div>
                        <form onSubmit={e => onSubmit(e)}>
                            <textarea className="request-textarea" type="text" name="task" value={task} onChange={e => onChange(e)} required="required" />
                            <div className='request-warning'>Task should be less than 250 characters in English</div>
                            <input type="submit" value="Submit" />
                        </form>
                    </div>
                </div>
            </Fragment>
    )
}


export default withRouter(NewRequest)
