import React, { Fragment, useState } from 'react'
import { useParams, withRouter } from 'react-router-dom';
import Spinner from '../shared/Utility/Spinner';
import { completeRequest } from '../../actions/request';
import { uploadFileLender } from '../../actions/file';

import './RequestCompletion.css';
import '../../../node_modules/react-notifications-component/dist/theme.css'

const RequestCompletion = ({ history }) => {
    const { id } = useParams();
    let [isLoading, setIsLoading] = useState(false);

    const [state, setState] = useState({
        file: null
    });

    const { file } = state;

    const onChange = e => {
        setState({ file: e.target.files[0] });
    }

    const onSubmit = async e => {
        e.preventDefault();
        setIsLoading(true);

        // Upload the photo
        await uploadFileLender(id, file);

        // Update (complete) the request
        await completeRequest(id, setIsLoading, history);

    };

    return (
        isLoading ? <Spinner /> :
            <Fragment>
                <form className="request-completion-container" onSubmit={e => onSubmit(e)}>
                    <h1>Complete the request</h1>
                    <div className='request-completion-warning'><span>Warning: Requester cannot complete their own request</span></div>
                    <div>
                        <div>Please upload a proof of completion<span>*</span></div>
                        {/* 
                            Note that there is additional validation in the back-end. 
                            The front-end validation was added to improve the user experience 
                        */}
                        <input type="file" name="photo" accept="image/jpeg,image/jpg,image/png" onChange={e => onChange(e)} />
                    </div>
                    <div className='request-completion-warning'>Photo must be in .png, .jpg, or .jpeg format and less then 1 megabyte</div>
                    <input className="request-completion-btn" type="submit" value="Submit" />
                </form>
            </Fragment>
    )
}

export default withRouter(RequestCompletion);
