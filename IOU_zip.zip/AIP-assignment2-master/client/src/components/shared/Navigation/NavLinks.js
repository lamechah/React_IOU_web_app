import React, { Fragment, useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { checkLogin } from '../../../actions/auth';
import "./NavLinks.css";

// setting the navigation link of page
const NavLinks = () => {

  let [isLoggedIn, setIsLoggedIn] = useState(false)

  // Check if user is logged in
  useEffect(() => {
    async function fetchData() {
      await checkLogin(setIsLoggedIn);
    };
    fetchData();
  }, []);

  // If the user is logged in, display below navigation
  const authLink = (
    <Fragment>
      <ul className="nav-links">
        <li>
          <Link to="/profile">
            My Profile
        </Link>
        </li>
        <li>
          <NavLink to="/logout" >
            Log out
        </NavLink>
        </li>
        <li>
          <NavLink to="/ranking/">
            Rankings
        </NavLink>
        </li>
        <li>
          <NavLink to="/requests/">
            Requests
        </NavLink>
        </li>
      </ul>
    </Fragment>
  )

  // If the user is NOT logged in, display below navigation
  const notAuthLink = (
    <ul className="nav-links">
      <li>
        <Link to="/">
          Home
      </Link>
      </li>
      <li>
        <NavLink to="/login" >
          Login
      </NavLink>
      </li>
      <li>
        <NavLink to="/register">
          Registration
      </NavLink>
      </li>
      <li>
        <NavLink to="/ranking/">
          Rankings
      </NavLink>
      </li>
      <li>
        <NavLink to="/requests/">
          Requests
      </NavLink>
      </li>
    </ul>
  )
  return (
    <Fragment>
      {isLoggedIn ? authLink : notAuthLink}
    </Fragment>
  );
};

export default NavLinks;
