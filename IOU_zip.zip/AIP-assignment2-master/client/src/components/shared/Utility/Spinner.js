// This is imported from react-notifications-component library.
// Below code was referenced from https://www.npmjs.com/package/react-spinners
import React from 'react';
import { css } from "@emotion/core";
import FadeLoader from "react-spinners/FadeLoader";

const spinner = css`
  display: block;
  margin: auto;
  margin-top: 20rem;
  border-color: #db2f54;
`;

export default () => (
  <FadeLoader
    css={spinner}
    size={200}
    color={"#e21e59"}
    loading={true}
  />
)
