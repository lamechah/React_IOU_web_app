// This is imported from react-notifications-component library.
// Below code was referenced from https://www.npmjs.com/package/react-notifications-component
import { store } from 'react-notifications-component';

export const addNotification = (title, message, type) => {
    store.addNotification({
        title: title,
        message: message,
        type: type,
        insert: "top",
        container: "top-right", // display the message on top-right side
        dismiss: {
            duration: 3000, // display the message for 3 seconds
            onScreen: false
        }
    })
}