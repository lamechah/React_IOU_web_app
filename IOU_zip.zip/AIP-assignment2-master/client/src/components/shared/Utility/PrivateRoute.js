// Reference: https://codedaily.io/tutorials/49/Create-a-ProtectedRoute-for-Logged-In-Users-with-Route-Redirect-and-a-Render-Prop-in-React-Router
import React, { useState, useEffect } from 'react'
import { Route, Redirect } from 'react-router-dom'
const axios = require("axios");

const PrivateRoute = ({ component: Component, ...rest }) => {
    const [isLoggedIn, setLoggedIn] = useState(null);
    // Check if the user is logged in
    async function checkLogin() {
        try {
            const userResponse = await axios.get('/api/auth/check_login');
            if (userResponse.status === 200) {
                setLoggedIn(true);
            }
        } catch {
            setLoggedIn(false);
            console.log("User is not logged in");
        }
    }
    useEffect(() => {
        checkLogin();
    }, []);

    // If the user is neither logged in nor not logged in, display below message
    if (isLoggedIn === null) {
        return (
            <div>Loading</div>
        )
    }
    // If the user is NOT logged in and tries to access private page, take the user to login page
    if (isLoggedIn === false) {
        return (<Route {...rest} render={(props) => <Redirect to='/login' />} />)
    }

    // If the user is logged in and tries to access private page, take the user to the requested page
    if (isLoggedIn === true) {
        return (<Route {...rest} render={(props) => <Component {...props} />} />)
    }
}

export default PrivateRoute;