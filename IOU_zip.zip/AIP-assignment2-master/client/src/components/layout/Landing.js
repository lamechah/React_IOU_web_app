import React, { Fragment } from 'react';
import RequestList from '../request/RequestList';

import './Landing.css';
import globeImg from '../../image/landing-globe.jpg';
import friendImg from '../../image/landing-friend.jpg';
import connectImg from '../../image/landing-connect.jpg';


const Landing = () => {
    return (
        <Fragment>
            <div className="landing-container">
                <h1 className="landing-heading">How it works?</h1>
                <div className="landing-grid grid">
                    <div>
                        <img src={globeImg}
                            height="180px" sizes="300px" alt="Globe" className="landing-image" />
                        <p>Keep track of shared requests and favors with people form the office or the club for free.</p>

                    </div>
                    <div>
                        <img src={friendImg}
                            height="180px" sizes="300px" alt="Friend" className="landing-image" />
                        <p>Add, repay and delete favors, post requests, and add the rewards you want before you forget</p>

                    </div>
                    <div>
                        <img src={connectImg}
                            height="180px" sizes="300px" alt="Connect" className="landing-image" />
                        <p>What are you waiting for? Register or login to record your favors in a simple way!</p>

                    </div>
                </div>
            </div>
            <hr />
            <RequestList />
        </Fragment>
    );
}

export default Landing;
