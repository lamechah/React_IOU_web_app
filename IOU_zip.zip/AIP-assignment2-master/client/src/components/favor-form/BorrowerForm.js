import React, { Fragment, useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { withRouter, useHistory } from 'react-router-dom';
import './CreateFavor.css';
import '../shared/UIElements/Button'
import { addNotification } from '../shared/Utility/Alert';
import UserDetails from './UserDetails.js';
import ItemDetails from './ItemDetails.js';
import Spinner from '../shared/Utility/Spinner';
import { createFavorBorrower } from '../../actions/favor.js'

//Load form if user is a Borrower
const BorrowerForm = () => {
    const [formData, setFormData] = useState({
        item: '',
        lender: '',
        quantity: '',
    });
    let { item, lender, quantity } = formData;
    let history = useHistory();
    let [isLoading, setIsLoading] = useState(false);

    //Get data when form changes
    const onChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });

    };

    //Post a favor when user submits form
    const onSubmit = async e => {
        e.preventDefault();
        setIsLoading(true);
        let newFavor = {
            item, lender, quantity
        }

        //Check for errors beofre posting
        let check = { item, lender, quantity }
        let errors = Object.values(check).some(o => o === '' || o === 'SELECT OPTION');
        if (errors !== true) {
            try {
                //Post favor
                await createFavorBorrower(newFavor, setIsLoading, history);
            } catch (err) {
                console.error(err.message);
                setIsLoading(false);
                addNotification('Submission failed', 'Please try again', 'danger')
            }
        } else {
            setIsLoading(false);
            addNotification('Submission failed', 'Please try again. Make sure you complete all the fields', 'danger')
        }
    }

    return (
        <Fragment>
            <Form onSubmit={e => onSubmit(e)}>
                <Form.Group controlId="lender" >
                    <Form.Label>Select the Lender<span>*</span></Form.Label>
                    <Form.Control as="select" name="lender" value={lender} onChange={e => onChange(e)}>
                        <UserDetails />
                    </Form.Control>
                </Form.Group>
                <div>
                    <Form.Group controlId="item" >
                        <Form.Label>Select the favor item<span>*</span></Form.Label>
                        <Form.Control as="select" name="item" value={item} onChange={e => onChange(e)}>
                            <ItemDetails />
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="quantity" >
                        <Form.Label>How many items?<span>*</span></Form.Label>
                        <div className='reward-warning'>Quantity must be a number that is greater than 0 and smaller than 21<span>*</span></div>
                        <Form.Control type="number" name="quantity" value={quantity} onChange={e => onChange(e)}>
                        </Form.Control>
                    </Form.Group>
                    {isLoading ? <Spinner /> : <Button variant="primary" type="submit">Submit</Button>}
                </div>
            </Form>
        </Fragment>
    )
}
export default withRouter(BorrowerForm)
