import React, { useEffect, useState } from "react";
import { useParams, withRouter } from "react-router-dom";
import Spinner from '../shared/Utility/Spinner';
import { getLoggedUser, repayFavorBorrower, repayFavorLender } from '../../actions/favor'
import { uploadFileFavor } from '../../actions/file';

import "./FavorCompletion.css";

const FavorCompletion = (props) => {
  const { id } = useParams();
  const [type, setType] = useState("");
  const [state, setState] = useState({
    file: null
  });
  let [isLoading, setIsLoading] = useState(false);
  const { file } = state;


  useEffect(() => {
    async function fetchUserType() {
      // Get the user id of logged in user
      const user = await getLoggedUser();
      props.user.borrowerid === user ? setType('borrower') : setType('lender');
    }
    fetchUserType();
  }, [props.user.borrowerid]);

  const onChange = e => {
    setState({ file: e.target.files[0] });
  }

  const onSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    // If the user is a borrower, upload a file to repay the favor
    if (type === 'borrower') {
      await uploadFileFavor(id, file);
      await repayFavorBorrower(id, setIsLoading, props.history);
    } else {
      await repayFavorLender(id, setIsLoading, props.history);
    }
  };

  return (
    isLoading ? <Spinner /> :
      <form className="favor-completion" onSubmit={(e) => onSubmit(e)}>
        <h1>Complete the Favor</h1>
        {type === 'borrower' ? (
          <div>
            <div>Please upload a proof of completion<span>*</span></div>
            <input type="file" name="photo" accept="image/jpeg,image/jpg,image/png" onChange={e => onChange(e)} />
            <div className="favor-completion-requirement">Photo must be in .png, .jpg, or .jpeg format and less than 1 megabyte</div>
          </div>
        ) :
          <div>
            <div>Are you sure to complete the favor?</div>
            <div>If so, please click the Submit button to complete the favor<span>*</span></div>
          </div>
        }
        <input className="favor-completion-btn" type="submit" value="Submit" />
      </form>
  );
};
export default withRouter(FavorCompletion);
