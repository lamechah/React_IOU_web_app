import React, { Fragment, useEffect, useState } from "react";
import { getUsers } from '../../actions/favor.js';

import '../shared/UIElements/Button';
import "./FavorFormDetails.css";

const UserDetails = () => {
    const [users, setUsers] = useState([]);

    // Get all the users
    useEffect(() => {
        async function getCharacters() {
            const users = await getUsers();
            setUsers(users.map(({ username, userid }) => ({ label: username, value: userid })));
        }
        getCharacters();
    }, []);

    // Display users in drop-down list
    return (
        <Fragment>
            <option>SELECT OPTION</option>
            {users.map(({ label, value }) => (
                <option key={value} value={value}>
                    {label}
                </option>
            ))}

        </Fragment>
    );
};

export default UserDetails;