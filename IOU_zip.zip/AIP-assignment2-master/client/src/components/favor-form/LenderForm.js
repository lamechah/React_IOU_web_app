import React, { Fragment, useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { withRouter, useHistory } from 'react-router-dom';
import './CreateFavor.css';
import '../shared/UIElements/Button';
import { addNotification } from '../shared/Utility/Alert';
import UserDetails from './UserDetails.js';
import ItemDetails from './ItemDetails.js';
import Spinner from '../shared/Utility/Spinner';
import { createFavorLender } from '../../actions/favor.js'
import { uploadFileFavor } from '../../actions/file';

//Load form if user is a Lender 
const LenderForm = () => {
    const [formData, setFormData] = useState({
        item: '',
        borrower: '',
        quantity: '',
    });
    let history = useHistory();
    let { item, borrower, quantity } = formData;
    const [state, setState] = useState({
        file: null
    });
    let [isLoading, setIsLoading] = useState(false);
    const { file } = state;

    // Checks that file uplaoded complies with size and format 
    // Note that there is additional validation in the back-end. 
    // The front-end validation was added to improve the user experience
    const onUpload = e => {
        if (e.target.files.length !== 0) {
            !e.target.files[0].name.match(/.(jpg|jpeg|png)$/i) || e.target.files[0].size >= 1000000 ?
                addNotification('File failed', 'Only .png, .jpg and .jpeg format with less than 1mb allowed!', 'danger') :
                setState({ file: e.target.files[0] });
        }
    }

    //Get data when form changes
    const onChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    //Post a favor when user submits form
    const onSubmit = async e => {
        e.preventDefault();
        setIsLoading(true);
        let newFavor = {
            item, borrower, quantity
        }
        let check = { item, borrower, quantity }

        // Check if the user has selected a valid value from the list
        let errors = Object.values(check).some(o => o === '' || o === 'SELECT OPTION');
        if (errors !== true) {
            try {
                // Check if the user has uploaded a valid photo
                if (file !== null) {
                    const id = await createFavorLender(newFavor, setIsLoading, history);
                    // Upload the photo
                    await uploadFileFavor(id, file);
                    addNotification('Submission completed', 'Favor is successfully added!', 'success');
                    history.goBack();
                } else {
                    setIsLoading(false);
                    addNotification('Submission failed', 'Please upload a valid photo', 'danger')
                }
            } catch (err) {
                console.error(err.message);
                setIsLoading(false);
                addNotification('Submission failed', 'Please try again', 'danger')
            }
        } else {
            setIsLoading(false);
            addNotification('Submission failed', 'Please try again. Make sure you complete all the fields', 'danger')
        }
    }
    return (
        <Fragment>
            <Form onSubmit={e => onSubmit(e)}>
                <div>
                    <Form.Group controlId="borrower" >
                        <Form.Label>Select the Borrower<span>*</span></Form.Label>
                        <Form.Control as="select" name="borrower" value={borrower} onChange={e => onChange(e)}>
                            <UserDetails />
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="photo" >
                        <Form.Label>Please upload a photo<span>*</span></Form.Label>
                        <Form.Control type="file" name="photo" accept="image/jpeg,image/jpg,image/png" onChange={e => onUpload(e)}>
                        </Form.Control>
                        <div className='request-completion-warning'>Photo must be in .png, .jpg, or .jpeg format and less then 1 megabyte</div>
                    </Form.Group>
                </div>
                <div>
                    <Form.Group controlId="item" >
                        <Form.Label>Select the favor item<span>*</span></Form.Label>
                        <Form.Control as="select" name="item" value={item} onChange={e => onChange(e)}>
                            <ItemDetails />
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="quantity" >
                        <Form.Label>How many items?<span>*</span></Form.Label>
                        <div className='reward-warning'>Quantity must be a number that is greater than 0 and smaller than 21<span>*</span></div>
                        <Form.Control type="number" name="quantity" value={quantity} onChange={e => onChange(e)}>
                        </Form.Control>
                    </Form.Group>
                    {isLoading ? <Spinner /> : <Button variant="primary" type="submit">Submit</Button>}
                </div>
            </Form>
        </Fragment>
    )
}
export default withRouter(LenderForm)

