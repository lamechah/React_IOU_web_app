import React, { Fragment, useEffect, useState } from "react";
import { getItems } from '../../actions/favor.js'

import '../shared/UIElements/Button'
import "./FavorFormDetails.css";

const ItemDetails = () => {
    const [items, setItems] = useState([]);

    // Get all the favor items
    useEffect(() => {
        async function getCharacters() {
            const body = await getItems()
            setItems(body.map(({ itemid, itemname }) => ({ label: itemname, value: itemid })));
        }
        getCharacters();
    }, []);

    // Display the items in drop-down list
    return (
        <Fragment>
            <option>SELECT OPTION</option>
            {items.map(({ label, value }) => (
                <option key={value} value={value}>
                    {label}
                </option>
            ))}

        </Fragment>
    );
};

export default ItemDetails;