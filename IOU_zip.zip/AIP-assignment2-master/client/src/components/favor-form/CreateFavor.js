import React, { Fragment, useState } from 'react';
import { Form, ToggleButton, ToggleButtonGroup } from 'react-bootstrap';
import { withRouter } from 'react-router-dom';
import './CreateFavor.css';
import '../shared/UIElements/Button';
import BorrowerForm from './BorrowerForm.js'
import LenderForm from './LenderForm.js'


const CreateFavor = () => {
    const [type, setType] = useState('');
    // If the user clicks Lender button, set the type to 'lender'
    function onLenderChange() {
        setType('lender')
    }
    // If the user clicks Lender button, set the type to 'borrower'
    function onBorrowerChange() {
        setType('borrower')
    }

    return (
        <Fragment>
            <div className="request-container">
                <h1>Add a Favor</h1>
                <div>
                    <div>
                        <br></br>
                        <h3>Are you the borrower or the lender ?</h3>
                        <br></br>
                        <Form.Group>
                            <ToggleButtonGroup type="radio" name="distribution" className="mb-1" style={{ paddingRight: 20 }}>
                                <ToggleButton name="lender" onClick={onLenderChange}>
                                    LENDER</ToggleButton>
                            </ToggleButtonGroup>
                            <ToggleButtonGroup type="radio" name="distribution" className="mb-1" style={{ paddingRight: 20 }}>
                                <ToggleButton name="borrower" onClick={onBorrowerChange}>
                                    BORROWER
                                    </ToggleButton>
                            </ToggleButtonGroup>
                        </Form.Group>
                    </div>
                    {/* 
                        If user is a borrower display BorrowForm 
                        If user is a borrower display LenderForm
                        If the user didn't select either Lender or Borrower, display the message
                    */}
                    {type === 'borrower' ? (<BorrowerForm />)
                        : type === 'lender' ? (<LenderForm />)
                            : <div>Please select either Lender or Borrower<span>*</span></div>
                    }
                </div>
            </div>
        </Fragment>
    )

}
export default withRouter(CreateFavor)
