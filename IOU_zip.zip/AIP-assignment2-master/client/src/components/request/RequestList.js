import React, { useState, useEffect, Fragment } from 'react';
import Pagination from "../shared/Utility/Pagination";
import Requests from './Requests'
import { getAllRequests } from '../../actions/request';

import './RequestList.css';

const RequestList = () => {

    const [requests, setRequests] = useState([]);

    const [searchTerm, setSearchTerm] = useState("");

    const [currentPage, setCurrentPage] = useState(1);
    const [requestsPerPage] = useState(10);

    // Get all current request
    useEffect(() => {
        async function fetchData() {
            await getAllRequests().then(setRequests)
        };
        fetchData();
    }, []);

    // Get current requests for pagination
    const lastRequest = currentPage * requestsPerPage;
    const firstRequest = lastRequest - requestsPerPage;
    const currentList = requests.slice(firstRequest, lastRequest);

    // Change page
    const paginate = pageNumber => setCurrentPage(pageNumber);

    const onChange = e => {
        setSearchTerm(e.target.value)
    };

    return (
        <Fragment>
            <div className="request-container">
                <h3>Current Requests</h3>
                <div className="request-search">
                    <input type="text" placeholder="Search by task" value={searchTerm} onChange={onChange} />
                </div>
                <table className="request-table">
                    <thead>
                        <tr>
                            <th>Date Created</th>
                            <th>Requester</th>
                            <th>Task</th>
                            <th>Rewards</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    {/* Display the list of current requests */}
                    <tbody>
                        <Requests requests={currentList} searchTerm={searchTerm} />
                    </tbody>
                </table>
                <Pagination
                    itemsPerPage={requestsPerPage}
                    totalItems={requests.length}
                    paginate={paginate} />
            </div>
        </Fragment>
    )
}

export default RequestList


