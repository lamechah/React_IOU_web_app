import React, { useState, useEffect, Fragment } from "react";
import RequestItem from "./RequestItem";
import RequestCompletion from "../request-form/RequestCompletion";
import Rewards from "../reward/Rewards";
import { useParams, withRouter } from "react-router-dom";
import { getRequest, deleteRequest } from "../../actions/request";
import { getLoggedInUser, checkLogin } from "../../actions/auth";

import Button from '../shared/UIElements/Button'
import "./Request.css";

const Request = ({ history }) => {
  const { id } = useParams();

  const [request, setRequest] = useState("");

  const [displayRewardsForm, toggleRewardsForm] = useState(false);

  const [displayCompletionForm, toggleCompletionForm] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState("");

  useEffect(() => {
    async function fetchData() {
      // Check if the user is logged in
      await checkLogin(setIsLoggedIn);

      // Get the request data by request id
      await getRequest(id).then(setRequest);

      // Get the logged in user id
      await getLoggedInUser().then(setUserId);
    }
    fetchData();
  }, [id]);

  return (
    <Fragment>
      <div className="request-container">
        <Button to="/requests">Back to all requests</Button>
        <div className="request-delete">
          {request.requesterid === userId && (
            <Button onClick={() => deleteRequest(id, history)}>Delete request</Button>
          )}
        </div>
        {/* Display the request detail */}
        <RequestItem
          requestid={request.requestid}
          requester={request.requester}
          task={request.task}
          dateCreated={request.datecreated}
        />
        {/* Display the list of rewards for the request */}
        <div className="request-reward-list">
          <Rewards displayRewardsForm={displayRewardsForm} />
          {displayCompletionForm && <RequestCompletion />}
        </div>
        <div>
          {/* If the user is logged in, allow the  user to add rewards */}
          {isLoggedIn && (
            <Button
              onClick={() => toggleRewardsForm(!displayRewardsForm)}
              type="button"
            >
              Click to add a reward
            </Button>
          )}
          {/* If the user is logged in, allow the  user to complete the request */}
          <div className="request-complete-btn">
            {isLoggedIn && (
              <Button
                onClick={() => toggleCompletionForm(!displayCompletionForm)}
                type="button"
              >
                Complete the request!
              </Button>
            )}
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default withRouter(Request);
