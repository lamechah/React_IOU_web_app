import React, { Fragment } from 'react'
import Moment from 'react-moment';
import RewardItemList from '../reward/RewardItemList';
import Button from '../shared/UIElements/Button'

const Requests = ({ requests, searchTerm }) => {
    // Display the list of request
    return requests
        // Filter the requests. It supports search funtionality
        .filter(
            request =>
                request.task.toString().toLowerCase().includes(searchTerm.toLowerCase())
        )
        .map(request => (
            request.fullfillerid === null &&
            <Fragment key={request.requestid}>
                <tr>
                    <td>
                        <Moment format='YYYY/MM/DD'>{request.dateCreated}</Moment>
                    </td>
                    <td>{request.username}</td>
                    <td>{request.task}</td>
                    <td>
                        <RewardItemList
                            requestid={request.requestid} />
                    </td>
                    <td>
                        <Button to={`/request/${request.requestid}`}>See more</Button>
                    </td>
                </tr>
            </Fragment>
        ))
}
export default Requests;