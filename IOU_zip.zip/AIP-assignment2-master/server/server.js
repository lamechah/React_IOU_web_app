const express = require("express");
const connectDB = require("./config/db");
const cookieParser = require("cookie-parser");
const path = require("path");
const fileUpload = require('express-fileupload');

const app = express();

// Connect Database
try {
  connectDB.connect();
  console.log("PostgreSQL connected");
} catch (err) {
  console.log(err.message);
  // Exit process with failure
  process.exit(1);
}

// Initiate Middleware
app.use(express.json({ extended: false }));
app.use(cookieParser());
app.use(fileUpload())

// Define routes
app.use("/api/users", require("./api/users"));
app.use("/api/auth", require("./api/auth"));
app.use("/api/profile", require("./api/profile"));
app.use("/api/favors", require("./api/favors"));
app.use("/api/requests", require("./api/requests"));
app.use("/api/rewards", require("./api/rewards"));
app.use("/api/ranking", require("./api/ranking"));
app.use("/api/items", require("./api/items"));
app.use("/api/party", require("./api/partyDetection"));
app.use("/api/file", require("./api/fileHandler"));
app.use("/img/favors", express.static(path.join("img", "favors")));
app.use("/img/requests", express.static(path.join("img", "requests")));

// For deployment
//app.use(express.static(path.join(__dirname, '../client/build')));
//app.get('*', (req, res) => {
// res.sendFile(path.resolve(__dirname, '../client', 'build', 'index.html'))
//})

const port = 5000;

app.listen(port, () => console.log(`Server started on port ${port}`));
