/**
 * @param {string}  content
 * @returns {boolean} If non Basic Latin (e.g. non-English) is detected, return true
 * @description  Validate whether the input consist of Basic Latin (Unicode block) 
 * For more information, refer to https://en.wikipedia.org/wiki/Basic_Latin_(Unicode_block)
 */
function validateLanguage(content) {
    return /[^\u0000-\u007f]/.test(content);
}

/**
 * @returns {boolean} If the beginning of the buffer does not match with PNG or JPG/JPEG magic number, return true
 * @description  Verify if the file is corrupt by using magic number (unicode)
 * For more information, refer to https://en.wikipedia.org/wiki/Magic_number_(programming)
 */
function validateImage(fileType, fileBuffer) {
    const pngUnicode = [137, 80, 78, 71, 13, 10, 26, 10];   //magic number for png
    const jpgUnicode = [255, 216];                          //magic number for jpg, jpeg
    const tempList = [];

    // Compare magic number with buffer of the uploaded file
    // If they do NOT match, the file is likey to be corrupted
    if (fileType === 'image/png' && fileBuffer.length > 8) {
        for (let i = 0; i < 8; i++) { tempList.push(fileBuffer[i]) }
        if (!pngUnicode.every(function (u, i) { return u === tempList[i]; })) {
            console.log("File corrupted")
            return true
        } else return false
    } else if ((fileType === 'image/jpeg' || fileType === 'image/jpg') && fileBuffer.length > 2) {
        for (let i = 0; i < 2; i++) { tempList.push(fileBuffer[i]) }
        if (!jpgUnicode.every(function (u, i) { return u === tempList[i]; })) {
            console.log("File corrupted")
            return true
        } else return false
    } else return true
}

module.exports = {
    validateLanguage,
    validateImage
}

