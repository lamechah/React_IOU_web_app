const Pool = require("pg").Pool;

const pool = new Pool({
    database: "aip"
    // For deployment
    //user: "postgres",
    //password: "admin"
});

module.exports = pool;
