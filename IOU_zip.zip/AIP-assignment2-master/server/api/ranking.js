const express = require('express');
const router = express.Router();
const db = require('../config/db');
var async = require('async');

// @route   GET api/ranking
// @desc    Get all rankings
// @access  Public
router.get('/', function (req, res) {

    // Get the top 10 users who lent most favor
    var query1 = `SELECT u.username as User, 
    COUNT(*) as Total_Favors_Given
    FROM favors f JOIN users u
    ON f.lenderId = u.userId
    GROUP BY u.username
    ORDER BY Total_Favors_Given DESC
    LIMIT 10;`

    // Get the top 10 users who borrowed most favor
    var query2 = `SELECT u.username as User, 
    COUNT(*) as Total_Favors_Received
    FROM favors f JOIN users u
    ON f.borrowerId = u.userId
    GROUP BY u.username
    ORDER BY Total_Favors_Received DESC
    LIMIT 10;`


    var return_data = {};

    async.parallel([
        function (parallel_done) {
            db.query(query1, [], function (err, results) {
                if (err) return parallel_done(err);
                return_data.table1 = results;
                parallel_done();
            });

        },
        function (parallel_done) {
            db.query(query2, [], function (err, results) {
                if (err) return parallel_done(err);
                return_data.table2 = results;
                parallel_done();
            });

        }
    ], function (err) {
        if (err) console.log(err);
        res.send(return_data);
    });
});



module.exports = router;
