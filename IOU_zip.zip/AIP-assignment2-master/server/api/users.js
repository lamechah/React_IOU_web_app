const express = require("express");
const router = express.Router();
const db = require("../config/db");
const bcrypt = require("bcryptjs");
const { check, validationResult } = require("express-validator");

const { validateLanguage } = require("../utils/unicodeValidator");

const auth = require("../middleware/auth");

// @route   POST api/users
// @desc    Register user
// @access  Public
router.post(
  "/",
  // Validation for username, email, and password
  [
    check("username", "Username is required").not().isEmpty(),
    check("username", "Username should be between 3 and 20 characters in English").isLength({ min: 3, max: 20 }),
    check("email", "Please include a valid email").isEmail(),
    check("passwords", "Please enter a password between 6 and 128 characters").isLength({ min: 6, max: 128 }),
  ],
  async (req, res) => {
    // If there is any validation error, return error
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      // Check if the email already exists
      let newUserEmail = await db.query(`select * from users where email=$1`, [
        req.body.email,
      ]);

      // Check if the username already exists
      let newUserName = await db.query(`select * from users where username=$1`, [
        req.body.username,
      ]);

      // Verify if the username includes any non-English
      const usernameLangCheck = validateLanguage(req.body.username)

      // Return error if:
      // 1. email already exists
      // 2. username already exists
      // 3. username includes non-English
      if (newUserEmail.rows.length !== 0) {
        return res
          .status(400)
          .json({ errors: [{ msg: "The email already exists" }] });
      } else if (newUserName.rows.length !== 0) {
        return res
          .status(400)
          .json({ errors: [{ msg: "Username already exists" }] });
      } else if (usernameLangCheck) {
        return res
          .status(400)
          .json({ errors: [{ msg: "Username cannot include non-English" }] });
      }

      // Encrypt password
      const salt = await bcrypt.genSalt(10);

      const encryptedPassword = await bcrypt.hash(req.body.passwords, salt);

      // Add user
      const results = await db.query(
        `INSERT INTO users (username, email, passwords) values ($1, $2, $3) returning *`,
        [req.body.username, req.body.email, encryptedPassword]
      );

      res.status(200).json({
        status: "success",
        data: {
          user: results.rows[0],
        },
      });
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Server error");
    }
  }
);

// @route   GET api/users
// @desc    Get all users execpt user logged in
// @access  Private
router.get('/', auth, async (req, res) => {
  try {
    const response = await db.query(
      `select DISTINCT userid, username from users WHERE NOT userid=$1 order by userid`, [req.userid]);
    const users = response.rows;
    res.json(users);

  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
