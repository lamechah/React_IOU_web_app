const express = require("express");
const router = express.Router();
const db = require("../config/db");
const { check, validationResult } = require("express-validator");

const auth = require("../middleware/auth");

const { validateLanguage } = require("../utils/unicodeValidator");

// @route   GET api/requests
// @desc    Get all current request
// @access  Public
router.get("/", async (req, res) => {
  try {
    const requests = await db.query(
      `select requests.*, username
            from requests 
            join users
            on userid=requesterid
            where fullfillerid is null
            order by requestid desc;`
    );
    res.json(requests.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   POST api/requests
// @desc    Create a request
// @access  Private
router.post(
  "/",
  auth,
  // Validation for task
  [
    check("task", "Please include the description of the task").not().isEmpty(),
    check(
      "task",
      "Task should be less than 250 characters in English"
    ).isLength({ max: 250 }),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    // If there is any validation error, return error
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const task = req.body.task;

      // Check if the task includes any non-English
      const result = validateLanguage(task);
      if (result) {
        return res
          .status(400)
          .json({ errors: { msg: "Please check if non-English is used" } });
      }

      // Create new request
      const newRequest = await db.query(
        `INSERT INTO requests (requesterid, task) values ($1, $2) returning *`,
        [req.userid, req.body.task]
      );
      res.status(200).json({
        status: "success",
        data: {
          user: newRequest.rows[0],
        },
      });
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Server Error");
    }
  }
);

// @route   POST api/requests/:requestid
// @desc    Update a request
// @access   Private
router.post("/:requestid", auth, async (req, res) => {
  try {
    // Check if the user is the requester
    let requester = await db.query(
      `select requesterid from requests where requestid=$1`,
      [req.params.requestid]
    );

    // Requester cannot complete the task
    if (requester.rows[0].requesterid != [req.userid]) {
      const hasPhoto = await db.query(
        `select photo from requests where requestid = $1`,
        [req.params.requestid]
      );

      // Return error if there is no photo
      if (hasPhoto.rows[0].photo == null) {
        return res.status(400).json({ msg: "Photo not uploaded" });
      }

      // Update database of the request
      const completedRequest = await db.query(
        `UPDATE requests SET fullfillerid = $1, datefinished=now() where requestid = $2 returning *`,
        [req.userid, req.params.requestid]
      );
      res.status(200).json({
        status: "success",
        data: {
          user: completedRequest.rows[0],
        },
      });
    } else {
      return res
        .status(404)
        .json({ msg: "Requester cannot complete their own request" });
    }
  } catch (err) {
    console.error(err.message);
    if (err instanceof TypeError) {
      return res.status(404).json({ msg: "Request not found" });
    }
    res.status(500).send("Server Error");
  }
});

// @route   DELETE api/requests/:requestid
// @desc    Delete a post
// @access   Private
router.delete("/:requestid", auth, async (req, res) => {
  try {
    // Check if the user is the requester
    const requester = await db.query(
      `select requesterid from requests where requestid=$1`,
      [req.params.requestid]
    );

    // Onle the Requester can delete the task
    if (requester.rows[0].requesterid != [req.userid]) {
      return res.status(401).json({ msg: "User not authorised" });
    }

    // Check if any reward for this request
    // If there is any reward for the request, it cannot be deleted
    const rewards = await db.query(`select * from rewards where requestid=$1`, [
      req.params.requestid,
    ]);
    if (rewards.rows.length !== 0) {
      return res
        .status(400)
        .json({ msg: "Request cannot be deleted when it has any reward" });
    }

    // Delete the request
    await db.query(`delete from requests where requestid=$1 returning *`, [
      req.params.requestid,
    ]);

    res.json({ msg: "Request removed" });
  } catch (err) {
    console.error(err.message);
    if (err instanceof TypeError) {
      return res.status(404).json({ msg: "Request not found" });
    }
    res.status(500).send("Server Error");
  }
});

// @route   GET api/requests/:requestid
// @desc    Get profile by request ID
// @access  Public
router.get("/:requestid", async (req, res) => {
  try {
    const request = await db.query(
      `select requests.*, username as requester
            from requests 
            join users
            on requests.requesterid=userid
            where requestid=$1`,
      [req.params.requestid]
    );

    if (request.rows.length === 0)
      return res.status(400).json({ msg: "Request not found" });

    res.status(200).json(request.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/requests/:requestid/completed
// @desc    Get completed request by request ID
// @access  Public
router.get("/:requestid/completed", async (req, res) => {
  try {
    const request = await db.query(
      `select requests.requestid as requestid, userid as borrower, fullfillerid as lender, itemid as item, quantity, photo
            from requests 
            join rewards
            on requests.requestid=rewards.requestid
            where requests.requestid=$1`,
      [req.params.requestid]
    );
    res.status(200).json(request.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
