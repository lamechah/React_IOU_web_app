const express = require("express");
const router = express.Router();
const db = require("../config/db");
const bcrypt = require("bcryptjs");

const auth = require("../middleware/auth");

// @route   GET api/profile
// @desc    Get all users
// @access  Public
router.get("/", async (req, res) => {
  try {
    const profiles = await db.query(`select * from users;`);
    res.json(profiles.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/profile/user
// @desc    Get the logged in user
// @access  Private
router.get("/user", auth, async (req, res) => {
  try {
    const profile = await db.query(`select * from users where userid=$1`, [
      req.userid,
    ]);

    if (profile.rows.length === 0)
      return res.status(400).json({ msg: "User not found" });

    res.status(200).json({
      status: "success",
      data: {
        user: profile.rows[0],
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/profile/user/favors
// @desc    Get favors by user
// @access  Private
router.get("/user/favors", auth, async (req, res) => {
  try {
    // Get the favors the user borrowed
    const favorBorrow = await db.query(
      `select * from favors where borrowerId=$1`,
      [req.userid]
    );

    // Get the favors the user lent
    const favorBorrowedByUser = await db.query(
      `select fav.favorid, fav.lenderid, us.username, fav.quantity, it.itemname from 
      favors as fav left join users as us ON fav. lenderid =us.userid left join items as it ON fav.itemid=it.itemid where 
      fav.datecompleted is NULL and fav. borrowerid=$1 order by fav.favorid desc;`,
      [req.userid]
    );

    // Get the favors the user borrowed
    const favorLentByUser = await db.query(
      `select fav.favorid, fav.borrowerid, us.username, fav.quantity, it.itemname from
       favors as fav left join users as us ON fav.borrowerid =us.userid left join items as it ON fav.itemid=it.itemid where 
       fav.datecompleted is NULL and fav.lenderid=$1 order by fav.favorid desc;`,
      [req.userid]
    );

    res.status(200).json({
      status: "success",
      data: {
        favorBorrow: favorBorrow.rows,
        favorBorrowedByUser: favorBorrowedByUser.rows,
        favorLentByUser: favorLentByUser.rows,
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/profile/user/myRequests
// @desc    Get requests by user
// @access  Private
router.get("/user/myRequests", auth, async (req, res) => {
  try {
    // Get the requests that the user created
    const request = await db.query(
      `select * from requests where requesterId=$1 and datefinished is null order by requestId desc;`,
      [req.userid]
    );

    // Get the requests that the user completed
    const requestAccepted = await db.query(
      `select req.requestid, req.requesterid, req.task, req.datefinished, us.username 
      from requests as req left join users as us ON req.requesterid=us.userid where req.fullfillerid=$1 
      order by req.requestid desc;`,
      [req.userid]
    );

    res.status(200).json({
      status: "success",
      data: {
        request: request.rows,
        requestAccepted: requestAccepted.rows,
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/profile/user/history
// @desc    Get transaction history of user
// @access  Private
router.get("/user/history", auth, async (req, res) => {
  try {
    // Get the favors that others paid to the user
    const peoplePaid = await db.query(
      `select fav.favorid, fav.borrowerid, fav.photo, us.username, fav.quantity, it.itemname, 
        fav.datecompleted from favors as fav left join users as us ON fav.borrowerid=us.userid left join items as it ON fav.itemid=it.itemid where fav.datecompleted 
        IS NOT NULL and fav.lenderid=$1 order by fav.favorid desc`,
      [req.userid]
    );

    // Get the favors that the user paid for others
    const userPaid = await db.query(
      `select fav.favorid, fav.lenderid, fav.photo, us.username, fav.quantity, it.itemname,
     fav.datecompleted from favors as fav left join users as us ON fav.lenderid =us.userid left join items as it ON fav.itemid=it.itemid where fav.datecompleted 
     IS NOT NULL and fav. borrowerid=$1 order by fav.favorid desc`,
      [req.userid]
    );

    res.status(200).json({
      status: "success",
      data: {
        peoplePaid: peoplePaid.rows,
        userPaid: userPaid.rows,
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

module.exports = router;
