const express = require("express");
const router = express.Router();
const db = require("../config/db");
const { check, validationResult } = require("express-validator");

const auth = require('../middleware/auth');

// @route   GET api/rewards/:requestid
// @desc    Get all rewards by request ID
// @access  Public
router.get("/:requestid", async (req, res) => {
  try {
    const rewards = await db.query(
      `select rewards.*, itemname, username
            from rewards 
            join items
            on items.itemid=rewards.itemid
            join users
            on rewards.userid=users.userid
            where requestid=$1`,
      [req.params.requestid]
    );

    res.json(rewards.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/rewards/:requestid/total	
// @desc    Get all rewards by request ID and group by itemid. It will return the total quantity of each item.
// @access  Public	
router.get("/:requestid/total", async (req, res) => {
  try {
    const totalRewards = await db.query(
      `select rewards.itemid, itemname, sum(rewards.quantity) as total	
      from rewards 	
      join items	
      on items.itemid=rewards.itemid	
      where requestid=$1	
      group by rewards.itemid, itemname`,
      [req.params.requestid]
    );

    res.json(totalRewards.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   POST api/rewards/:requestid
// @desc    Create a reward
// @access   Private
router.post("/:requestid", auth,
  // Validation for item id and quantify
  [
    check("itemid", "Please select the item").isInt(),
    check("quantity", "Please enter the quantity greater than 0").isInt({ gt: 0, lt: 21 }),
  ],
  async (req, res) => {
    // If there is any validation error, return error
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      // Check if the reward already exist.
      // If so, update the quantify of the reward
      // If not, create a new reward
      const isRewardExist = await db.query(
        `select * from rewards where requestid=$1 and itemid=$2 and userid=$3`,
        [req.params.requestid, req.body.itemid, req.userid]
      )
      if (isRewardExist.rows.length === 0) {
        const newReward = await db.query(
          `INSERT INTO rewards (requestid, itemid, quantity, userid) values ($1, $2, $3, $4) returning *`,
          [
            req.params.requestid,
            req.body.itemid,
            req.body.quantity,
            req.userid,
          ]
        );
        res.json(newReward.rows[0])
      } else {
        const updatedReward = await db.query(
          `UPDATE rewards SET quantity = quantity + $1 where rewardid=$2 returning *`,
          [
            req.body.quantity,
            isRewardExist.rows[0].rewardid
          ]
        );
        res.json(updatedReward.rows[0])
      }


    } catch (err) {
      console.error(err.message);
      if (err instanceof TypeError) {
        return res.status(404).json({ msg: "Request not found" });
      }
      res.status(500).send("Server Error");
    }
  }
);

// @route   DELETE api/rewards/:rewardId
// @desc    Delete a reward
// @access   Private
router.delete("/:rewardId", auth, async (req, res) => {
  try {
    // Check if the user is the requester
    let rewarder = await db.query(
      `select userId from rewards where rewardId=$1`,
      [req.params.rewardId]
    );

    // Only the user who created the reward can deleted the reward
    if (rewarder.rows[0].userid != [req.userid]) {
      return res.status(401).json({ msg: "User not authorised" });
    }

    // Delete the reward
    await db.query(`delete from rewards where rewardId=$1 returning *`,
      [req.params.rewardId,]
    );
    res.json({ msg: "Reward removed" });
  } catch (err) {
    console.error(err.message);
    if (err instanceof TypeError) {
      return res.status(404).json({ msg: "Reward not found" });
    }
    res.status(500).send("Server Error");
  }
});

module.exports = router;
