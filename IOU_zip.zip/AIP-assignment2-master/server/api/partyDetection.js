const express = require("express");
const router = express.Router();
const db = require("../config/db");

const auth = require("../middleware/auth");

// @route   GET api/party
// @desc    Get all party
// @access  Private
router.get("/", auth, async (req, res) => {
    try {
        const favors = await db.query(`
        select favors.favorid, lenderid, borrowerid, party.partyid, isactive 
        from favors 
        join favor_party on favors.favorid=favor_party.favorid 
        join party on favor_party.partyid = party.partyid
        where (lenderid=$1 or borrowerid=$1)
        and isactive=1`,
            [req.userid]);
        res.json(favors.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// @route   GET api/party/:favorid
// @desc    Get all parties related to a certain favour
// @access  Private
router.get("/:favorid", auth, async (req, res) => {
    try {
        const result = await db.query(`
        select * from favor_party 
        join party on party.partyid=favor_party.partyid 
        where favorid=$1 and isactive=1`,
            [req.params.favorid]);
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// @route   GET api/party/:favorid/:partyid
// @desc    Get all favors related to a certain party
// @access  Private
router.get("/:favorid/:partyid", auth, async (req, res) => {
    try {
        const result = await db.query(`
        select party.*, username
        from party 
        join favor_party on favor_party.partyid=party.partyid 
        join favors on favor_party.favorid=favors.favorid 
        join users on users.userid=favors.lenderid 
        where party.partyid=$1 and isactive=1`,
            [req.params.partyid]);
        res.json(result.rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).send("Server Error");
    }
});

// @route   POST api/party/trigger
// @desc    Invoke the party detection
// @access  Public
router.post("/trigger", async (req, res) => {
    try {
        // Get all the Favor records
        const result = await db.query(
            `select favors.favorid, favors.lenderid, favors.borrowerid, itemid, quantity
            from favors
            where datecompleted is null
            and party is null;`
        );
        const favors = result.rows;

        let isParty = false;

        let firstFavor, secondFavor, thirdFavor, fourthFavor;

        /**
         * Compare the lender, borrower, itemid, quanitity of each favor to detect a cycle
         * A party will be detected if:
         * 1. Borrower of Favor A matches with Lender of Favor B AND item ID and quantity are the same
         * 2. Borrower of Favor B matches with Lender of Favor C AND item ID and quantity are the same
         * 3. Borrower of Favor C matches with Lender of Favor D AND Borrower of Favor D matches with Lender of Favor A AND item ID and quantity are the same
         */
        if (favors.length !== 0) {
            for (i = 0; i < favors.length - 1; i++) {
                for (j = i + 1; j < favors.length; j++) {
                    if (favors[i].borrowerid === favors[j].lenderid && favors[i].itemid === favors[j].itemid && favors[i].quantity === favors[j].quantity) {
                        for (n = 0; n < favors.length; n++) {
                            if (favors[j].borrowerid === favors[n].lenderid && favors[j].itemid === favors[n].itemid && favors[j].quantity === favors[n].quantity) {
                                for (m = 0; m < favors.length; m++) {
                                    if (favors[n].borrowerid === favors[m].lenderid && favors[m].borrowerid === favors[i].lenderid && favors[n].itemid === favors[m].itemid && favors[n].quantity === favors[m].quantity) {
                                        isParty = true;
                                        firstFavor = favors[i];
                                        secondFavor = favors[j];
                                        thirdFavor = favors[n];
                                        fourthFavor = favors[m];
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // If a party is detected, update the Party and favor_party database
            if (isParty) {
                try {
                    await db.query(
                        `UPDATE favors SET party = 1 where favorId in ($1, $2, $3, $4)`,
                        [firstFavor.favorid, secondFavor.favorid, thirdFavor.favorid, fourthFavor.favorid]
                    )
                    const newParty = await db.query(`INSERT INTO party (isactive) values (1) returning *`)
                    const newPartyId = newParty.rows[0].partyid
                    await db.query(`INSERT INTO favor_party (favorid, partyid) values ($1, $5), ($2, $5), ($3, $5), ($4, $5) returning *`,
                        [firstFavor.favorid, secondFavor.favorid, thirdFavor.favorid, fourthFavor.favorid, newPartyId]);
                } catch (err) {
                    console.error(err.message);
                }
            }
        }
        res.status(200).json({ msg: "Party detection success" })

    } catch (err) {
        res.status(500).send("Server Error");
        console.error(err.message);
    }
})


module.exports = router;
