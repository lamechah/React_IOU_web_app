const express = require('express');
const router = express.Router();
const db = require('../config/db');

// @route   GET api/items
// @desc    Get all items
// @access  Public
router.get('/', async (req, res) => {
    try {
        const items = await db.query(
            `select * from items order by itemid;`
        );

        res.json(items.rows);


    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// @route   GET api/items/
// @desc    Get all items of a reward 
// @access  Public
router.get('/favorItems', async (req, res) => {
    try {
        const favors = await db.query(
            `select DISTINCT itemName, itemid from items;`
        );
        const items = (favors.rows);
        res.json(items);

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});
module.exports = router;

