const express = require("express");
const router = express.Router();
const db = require("../config/db");
const { check, validationResult } = require("express-validator");

const auth = require("../middleware/auth");

// @route   GET api/favors
// @desc    Get all favors
// @access  Public
router.get("/", async (req, res) => {
  try {
    const favors = await db.query(`select * from favors;`);
    res.json(favors.row);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/favors
// @desc    Get favor & user info of a favor that the user lent
// @access  Public
router.get("/people/:favorid", async (req, res) => {
  try {
    const favor = await db.query(
      `select us.username, fav.favorid, fav.borrowerid, fav.lenderid, fav.photo, it.itemname, 
      fav.quantity, fav.datecreated from favors as fav left join items as it ON fav.itemid=it.itemid left join 
      users as us ON fav.borrowerid=us.userid where fav.favorid=$1;`,
      [req.params.favorid]
    );
    res.json(favor.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   GET api/favors
// @desc    Get favor & user info of a favor that the user borrowed
// @access  Public
router.get("/user/:favorid", async (req, res) => {
  try {
    const favor = await db.query(
      `select us.username, fav.favorid, fav.borrowerid, fav.lenderid, fav.photo, it.itemname,
      fav.quantity, fav.datecreated from favors as fav left join items as it ON fav.itemid=it.itemid left join
      users as us ON fav.lenderid=us.userid where fav.favorid=$1;`,
      [req.params.favorid]
    );
    res.json(favor.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

// @route   POST api/favors/lender
// @desc    Create a favor as Lender
// @access  Private
router.post("/lender", auth,
  // Validation for quantity 
  [
    check("quantity", "Please enter the quantity greater than 0").isInt({ gt: 0, lt: 21 }),
  ],
  async (req, res) => {
    // If there is any validation error, return error
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      // Create a new favor
      const newFavor = await db.query(
        `INSERT INTO favors (lenderid, borrowerid, requestid, photo, itemID, quantity) values ($1, $2, $3, $4, $5, $6) returning *`,
        [req.userid, req.body.borrower, req.body.requestid, req.body.photo, req.body.item, req.body.quantity]
      );

      res.status(200).json({
        status: "succes",
        data: {
          user: newFavor.rows[0],
        },
      });
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Server Error");
    }
  }
);

// @route   POST api/favors/lender
// @desc    Create a favor as Borrower
// @access  Private
router.post("/borrower", auth,
  // Validation for quantity 
  [
    check("quantity", "Please enter the quantity greater than 0").isInt({ gt: 0, lt: 21 }),
  ],
  async (req, res) => {
    // If there is any validation error, return error
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      // Create a new favor
      const favorCompleted = await db.query(
        `INSERT INTO favors (lenderid, borrowerid, requestid, itemID, quantity) values ($1, $2, $3, $4, $5) returning *`,
        [req.body.lender, req.userid, req.body.requestid, req.body.item, req.body.quantity]
      );

      res.status(200).json({
        status: "succes",
        data: {
          user: favorCompleted.rows[0],
        },
      });
      // console.log(newFavor)
    } catch (err) {
      console.error(err.message);
      res.status(500).send("Server Error");
    }
  });


// @route   POST api/favors/lender/complete/:favorid
// @desc    Update the favor that is completed
// @access  Private
router.post("/lender/complete/:favorid", auth, async (req, res) => {
  try {
    // Update the completed date in Favor table
    const favorCompleted = await db.query(
      `UPDATE favors SET datecompleted=now() where favorid = $1 returning *`,
      [req.params.favorid]
    );

    // Check if the favor is part of a party
    const parties = await db.query(
      `select partyId from favor_party 
      join favors on favor_party.favorid=favors.favorid
      where favors.favorid=$1`,
      [req.params.favorid]
    );

    // If the favor is part of a party, update the Party table
    if (parties.rows.length !== 0) {
      await db.query(`UPDATE party SET isactive=0 where partyid=$1 returning *`, [parties.rows[0].partyid]);
    }

    res.status(200).json({
      status: "success",
      data: {
        user: favorCompleted.rows[0],
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});

router.post("/borrower/complete/:favorid", auth, async (req, res) => {
  try {
    // const file = req.file;
    const isUploaded = await db.query(`select * from favors where favorid=$1 and photo is not null`,
      [req.params.favorid])

    if (isUploaded.rows.length === 0)
      return res.status(400).json({ msg: "Photo not uploaded" });

    const favorCompleted = await db.query(
      `UPDATE favors SET datecompleted=now() where favorid = $1 returning *`,
      [req.params.favorid]
    );

    const parties = await db.query(
      `select partyId from favor_party 
      join favors on favor_party.favorid=favors.favorid
      where favors.favorid=$1`, [req.params.favorid]
    )

    if (parties.rows.length !== 0) {
      await db.query(`UPDATE party SET isactive=0 where partyid=$1 returning *`, [parties.rows[0].partyid]);
    }

    res.status(200).json({
      status: "success",
      data: {
        user: favorCompleted.rows[0],
      },
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
});


// @route   DELETE api/favors/:favorid/
// @desc    Delete a favor
// @access  Private
router.delete("/:favorid", auth, async (req, res) => {
  try {
    await db.query(`delete from favor_party where favorid=$1`, [req.params.favorid])
    await db.query(`delete from favors where favorid=$1`, [req.params.favorid]);
    res.json({ msg: "Favor Removed" });
  } catch (err) {
    console.error(err.message);
    if (err instanceof TypeError) {
      return res.status(404).json({ msg: "Favor not found" });
    }
    res.status(500).send("Server Error");
  }
});

module.exports = router;
