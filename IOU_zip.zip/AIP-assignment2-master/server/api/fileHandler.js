const express = require("express");
const router = express.Router();
const fs = require("fs");
const db = require("../config/db");
const { validateImage } = require("../utils/unicodeValidator");

// @route   POST api/file/:id
// @desc    Upload file
// @access  Public
router.post('/:id', async (req, res) => {
    try {
        // Check if there is any file being uploaded
        if (!req.files || Object.keys(req.files).length === 0) {
            console.log('No file')
            return res.status(400).json({ msg: "Photo not uploaded" });
        }

        // Get the type of the request. It's either 'requests' or 'favors'
        const type = req.body.type

        // Define file info
        const file = req.files.photo;
        const fileName = file.name;
        const fileType = file.mimetype;
        const fileSize = file.size;
        const fileBuffer = file.data;

        // Validate file format and file size
        if (fileType !== 'image/png' && fileType !== 'image/jpeg' && fileType !== 'image/jpg') {
            console.log("File type wrong")
            return res.status(400).json({ msg: "Wrong file format" });
        } else if (fileSize > 1000000) { //file size should be less than 1000000 byte (=1 megabyte)
            console.log("File too big")
            return res.status(400).json({ msg: "File is too big" });
        }

        // Verify if the file is corrupt
        const isCorrupt = validateImage(fileType, fileBuffer)
        if (isCorrupt) {
            return res.status(400).json({ msg: "File is corrupted" });
        }

        // Recursively create the folder
        fs.mkdirSync(`./img/${type}`, { recursive: true });

        let photo;
        // Check if the request is made from Request or Favor
        if (type === 'requests') {
            // Move the file to the designated folder
            file.mv(`./img/requests/${req.params.id}-${fileName}`, function (err) {
                if (err) {
                    console.log('Error during saving file')
                    return res.status(500).send(err);
                }
            });
            // Update database to populate the location of the photo
            photo = await db.query(
                `UPDATE requests SET photo = $1 where requestid = $2 returning *`,
                [`/img/requests/${req.params.id}-${fileName}`, req.params.id]
            );
        } else {
            // Move the file to the designated folder
            file.mv(`./img/favors/${req.params.id}-${fileName}`, function (err) {
                if (err) {
                    console.log('Error during saving file')
                    return res.status(500).send(err);
                }
            });
            // Update database to populate the location of the photo
            photo = await db.query(
                `UPDATE favors SET photo = $1 where favorid = $2 returning *`,
                [`/img/favors/${req.params.id}-${fileName}`, req.params.id]
            );
        }
        res.status(200).json(photo.rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).send({ msg: "Server Error" });
    }
});


module.exports = router;
