const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const bcrypt = require("bcryptjs");

router.use(cookieParser());
const secret = 'super_secret';
const db = require('../config/db');

// @route   POST api/auth/login
// @desc    Authenticate user. 
// @access  Public
router.post('/login', async (req, res) => {
    const email = req.body.email;
    const password = req.body.passwords;

    const query = await db.query(
        `Select * From users where email = $1`,
        [email]
    );

    // If there is no result found, return error
    if (query.rowCount == 0) {
        return res
            .status(400)
            .json({ errors: [{ msg: "Email not found", title: "Email" }] })
    }

    const hash = query.rows[0].passwords;
    // Verify if the password is correct using hash
    const isPasswordCorrect = bcrypt.compareSync(password, hash);

    // If the password is not correct, return error
    if (!isPasswordCorrect) {
        return res
            .status(400)
            .json({ errors: [{ msg: "Password is incorrect", title: "Password" }] });
    }

    // Set the payload using userid
    let payload = { id: query.rows[0].userid };

    let token = jwt.sign(
        payload,
        secret,
        { expiresIn: '30 minutes' }
    );

    // Set the cookie for authentication
    res.cookie('jwt', token, {
        httpOnly: true,
        sameSite: 'strict'
    });

    return res.status(200).send('You have logged in');

});

// @route   GET api/auth/check_login
// @desc    Check whether user is logged in or not. Source code: https://www.benjaminjohnston.com.au/extras/aipjs/workbook/chapter09_login.html
// @access  Public
router.get('/check_login', (req, res) => {
    try {
        // Check if there is a cookie for authentication
        if (req.cookies.jwt) {
            let payload = jwt.verify(
                req.cookies.jwt,
                secret
            );
            res.status(200).json({
                status: "succes",
                data: {
                    userid: payload.id,
                },
            });
        } else {
            res.status(400).send('You are not logged in');
        }
    } catch (e) {
        res.status(400).send('Your JWT is invalid or expired. Log in again.');
    }
});

// @route   GET api/auth/logout
// @desc    Log out the user by setting expiry time to -1 min
// @access  Public
router.get('/logout', (req, res) => {
    let payload = { id: 0 };
    let token = jwt.sign(
        payload,
        secret,
        { expiresIn: '-1 minutes' }
    );

    res.cookie('jwt', token, {
        httpOnly: true,
        sameSite: 'strict'
        //secure: true
    });

    return res.status(200).send('You have logged out');
});

module.exports = router;
