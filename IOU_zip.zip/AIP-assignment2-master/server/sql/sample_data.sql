\echo
\echo ------------------------
\echo Inserting sample data
\echo ------------------------
\set ECHO all

insert into users
    (userName, email, passwords) 
values 
    ('Mercedes', 'mercedes@gmail.com', '$2a$10$amc/NEtEn7eUEtX9opS.WeMQFj3D.RJ56L4mVzVXZ4t0u3ZAa.si2'),
    ('Renato', 'renato@gmail.com', '$2a$10$amc/NEtEn7eUEtX9opS.WeMQFj3D.RJ56L4mVzVXZ4t0u3ZAa.si2'),
    ('Yoojin', 'yoojin@gmail.com', '$2a$10$amc/NEtEn7eUEtX9opS.WeMQFj3D.RJ56L4mVzVXZ4t0u3ZAa.si2'),
    ('Saurabh', 'saurabh@gmail.com', '$2a$10$amc/NEtEn7eUEtX9opS.WeMQFj3D.RJ56L4mVzVXZ4t0u3ZAa.si2');


insert into items
    (itemName) 
values 
    ('Chocolate'),
    ('Candy'),
    ('Coffee'),
    ('Pizza'),
    ('Tacos'),
    ('Beer');

insert into requests
    (requesterId, task) 
values 
    (
        (SELECT userId FROM users WHERE userName='Renato'),
        'Clean the office'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Yoojin'),
        'Water the plants'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Mercedes'),
        'Organise the main desk'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Saurabh'),
        'Wash the dishes'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Renato'),
        'Fix the printer'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Saurabh'),
        'Buy toilet papper'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Mercedes'),
        'Look after my dog while I go away'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Yoojin'),
        'Get hand sanitiser for the office'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Renato'),
        'Throw a team party'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Saurabh'),
        'Wipe the floor'
    ),
    (           
        (SELECT userId FROM users WHERE userName='Saurabh'),
        'Clean the window'
    );

insert into rewards
    (requestId, itemId, quantity, userId) 
values 
    (1,1,5,2),
    (1,2,2,2),
    (2,4,5,3),
    (3,3,2,1),
    (3,5,1,1),
    (4,1,11,4),
    (5,2,2,2),
    (5,4,5,1),
    (6,3,2,4),
    (6,5,15,4),
    (6,1,5,1),
    (7,2,2,1),
    (7,4,8,1),
    (8,3,2,3),
    (9,5,1,2),
    (10,5,1,4),
    (11,5,1,4);

insert into favors
    (lenderId, borrowerId, photo, dateCompleted, itemId, quantity) 
values 
    (
        (SELECT userId FROM users WHERE userName='Renato'),
        (SELECT userId FROM users WHERE userName='Mercedes'),
        '/img/favors/1-chocolate.jpg',
        '2020-09-15',
        1,
        5
    ),
    (
        (SELECT userId FROM users WHERE userName='Saurabh'),
        (SELECT userId FROM users WHERE userName='Renato'),
        '/img/favors/2-coffee.jpg',
        '2020-09-30',
        3,
        1
    );

insert into favors
    (lenderId, borrowerId, photo, itemId, quantity) 
values 
    (
        (SELECT userId FROM users WHERE userName='Yoojin'),
        (SELECT userId FROM users WHERE userName='Saurabh'),
        '/img/favors/3-candy.jpg',
        2,
        5
    ),
    (
        (SELECT userId FROM users WHERE userName='Saurabh'),
        (SELECT userId FROM users WHERE userName='Mercedes'),
        '/img/favors/4-pizza.jpg',
        4,
        3
    );

-- Sample data for party detection
-- Add Saurab lending 5 candies to Mercedes to trigger Party
insert into favors
    (lenderId, borrowerId, itemId, quantity) 
values 
    (
        (SELECT userId FROM users WHERE userName='Mercedes'),
        (SELECT userId FROM users WHERE userName='Renato'),
        2,
        5
    ),
    (
        (SELECT userId FROM users WHERE userName='Renato'),
        (SELECT userId FROM users WHERE userName='Yoojin'),
        2,
        5
    );


