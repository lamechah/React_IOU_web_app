\echo
\echo ------------------------
\echo Creating database schema
\echo ------------------------
\set ECHO queries

create table if not exists users(
    userId SERIAL PRIMARY KEY,
    userName TEXT NOT NULL,
    email TEXT NOT NULL,
    passwords TEXT NOT NULL
);

create table if not exists items(
    itemId SERIAL PRIMARY KEY,
    itemName TEXT NOT NULL
);

create table if not exists requests(
    requestId SERIAL PRIMARY KEY,
    requesterId INTEGER NOT NULL REFERENCES users,
    fullfillerId INTEGER REFERENCES users,
    task TEXT NOT NULL,
    photo TEXT,
    dateCreated DATE DEFAULT CURRENT_DATE,
    dateFinished DATE 
);
create table if not exists rewards(
    rewardId SERIAL PRIMARY KEY,
    requestId INTEGER NOT NULL REFERENCES requests,
    itemId INTEGER NOT NULL REFERENCES items,
    quantity NUMERIC NOT NULL,
    userId INTEGER REFERENCES users
);

create table if not exists favors(
    favorId SERIAL PRIMARY KEY,
    requestId INTEGER REFERENCES requests,
    lenderId INTEGER NOT NULL REFERENCES users,
    borrowerId INTEGER NOT NULL REFERENCES users,
    photo text,
    itemId INTEGER NOT NULL REFERENCES items,
    quantity INTEGER NOT NULL,
    dateCreated DATE DEFAULT CURRENT_DATE,
    dateCompleted DATE,
    party INTEGER
);

create table if not exists party(
    partyId SERIAL PRIMARY KEY,
    isActive INTEGER
);


create table if not exists favor_party(
    favorPartyId SERIAL PRIMARY KEY,
    favorId INTEGER NOT NULL REFERENCES favors,
    partyId INTEGER NOT NULL REFERENCES party
);