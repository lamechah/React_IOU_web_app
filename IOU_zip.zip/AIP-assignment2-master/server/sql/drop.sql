\echo
\echo ------------------------
\echo Dropping database schema
\echo ------------------------
\set ECHO all

drop table rewards, favor_party, users, requests, favors, items, party;