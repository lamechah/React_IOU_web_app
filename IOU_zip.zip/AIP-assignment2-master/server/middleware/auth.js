const jwt = require('jsonwebtoken');
const secret = 'super_secret';

// Authentication middleware
// It sends the user id of the logged in user
module.exports = function (req, res, next) {
    try {
        if (req.cookies.jwt) {
            let payload = jwt.verify(
                req.cookies.jwt,
                secret
            );
            req.userid = payload.id
            next()

        } else {
            console.log("Invalid Token");
            res.status(400).send('You are not logged in');
        }
    } catch (e) {
        res.status(400).send('Your JWT is invalid or expired. Log in again.');
    }

}