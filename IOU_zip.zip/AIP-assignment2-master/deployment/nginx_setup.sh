#!/bin/bash

# @author   Yoo Jin Chang
# @desc     Do NOT just run this script. You will need to remove some of the steps

# Step1 - Get the nginx signing key
sudo wget http://nginx.org/keys/nginx_signing.key 
sudo apt-key add nginx_signing.key

# Step2 - Update source list
cd /etc/apt/
sudo nano source_list
# Add the below in source_list
deb https://nginx.org/packages/mainline/ubintu/ bionic nginx 
deb-src https://nginx.org/packages/mainline/debian/ bionic nginx

# Step3 - Install nginx and pm2
sudo apt-get update
sudo apt-get install nginx
sudo npm install pm2
sudo service nginx start

# Step4 - Start pm2
cd /AIP-assignment/server/
pm2 start --name aip-1 server.js -- --name aip-1 --port 5000
pm2 start --name aip-2 server.js -- --name aip-2 --port 5001
pm2 start --name aip-3 server.js -- --name aip-3 --port 5002

# Step5 - Change nginx config file. For the full content, refer to default.conf
cd /etc/nginx/conf .d/
nano default
# Add the below in default
upstream aip {
	server localhost:5000;
	server localhost:5001;
    server localhost:5002;
}

location / {
	proxy_http_version 1.1;
	proxy_set_header Upgrade $http_upgrade;
	proxy_set_header Connection “upgrade”;
	proxy_pass “http://aip/”;
}

# Step6 - Set Startup Script Generator
# For more information, refer to https://pm2.keymetrics.io/docs/usage/startup/
pm2 startup
# Copy and paste the output into the terminal
pm2 save

<< 'END_COMMENT'
Other useful comments:
1. pm2
pm2 ls -> shows all the instances running
pm2 stop all -> stop all the instances
pm2 unstartup -> stop starting pm2 upon starting server
2. nginx
service nginx status -> shows the status of nginx
systemctl reload nginx -> reloads nginx after updating config file

Load test commands:
npx loadtest -c 1 -n 1000 http://<localhost>:5000/
npx loadtest -c 4 -n 1000 http://<localhost>:5000/
npx loadtest -P '{"email":"yoojin@gmail.com", "passwords}' -T application/json -c 1 -n 100 http://localhost:5000/login
END_COMMENT

